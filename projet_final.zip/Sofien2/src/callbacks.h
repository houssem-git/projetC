#include <gtk/gtk.h>


void
on_housing_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_hotel_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_consultHotel_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_homehotel_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_addHotel_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_returnListeHotel_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);



void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_deleteHotel_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modifh_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_modifyyy_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_Inscription_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_AjouterAgent_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_Login_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_AjouterAgentInsc_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_AjouterHotel_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_AfficherHotel_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_HomeHotel_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_Supprimer_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_Retour_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_Home_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_HotelTree_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_hom_clicked                         (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modifierHotel_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modifierHotelRedirect_clicked       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_HomeMotel_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_AfficherMotel_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_AjouterMotel_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_hom1_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_supprimerMotelRedirect_clicked      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modifierMotelRedirect_clicked       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modifierMotel_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modifierHRentalRedirect_clicked     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_supprimerHRentalRedirect_clicked    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retourHRentalRedirect_clicked       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_hom2_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modifierHrental_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_AjouterHouseRental_clicked          (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_AfficherHouseRental_clicked         (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_HomeHouseRental_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_AjouterGHouse_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_HomeGhouse_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_AfficherGhouse_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modifierGHouseRedirect_clicked      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_supprimerGHouseRedirect_clicked     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_hom3_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modifierGHouse_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_motell_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_house_rental_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_guest_house_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_AjouterClientInsc_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_HousingClient_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_HotelClient_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_MotelClient_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_HouseClient_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_GHouseClient_activate               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_reserverHotel_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ReserverMotel_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_reserverMaison_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_consulterReservation_clicked        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_reserverGHouse_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_treeReservation_row_activated       (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_supprimerReservationClient_clicked  (GtkWidget       *objet,
                                        gpointer         user_data);
