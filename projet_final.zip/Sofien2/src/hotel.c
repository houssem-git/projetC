#include <gtk/gtk.h>
#include "hotel.h" 
#include <string.h>
#include <stdlib.h>
enum
{
 NOUN,
 LOCATION,
 STARSNUMBER,
 FROM,
 TO,
 COLUMNS
};
void ajouterhotel(GtkWidget       *objet)
{	Hotel h;
  FILE *f;
  int jf,mf,af,jt,mt,at;
  GtkWidget *input1 ,*input2,*input3,*input4,*input5,*input6,*input7,*input8;
  GtkWidget *combobox1;
/**************************************************************************************************/
  input1= lookup_widget(objet,"jourfrom") ;
  input2= lookup_widget(objet,"moisfrom") ;
  input3= lookup_widget(objet,"anneefrom") ;
  input4= lookup_widget(objet,"jourto") ;
  input5= lookup_widget(objet,"moisto") ;
  input6= lookup_widget(objet,"anneeto") ;
    
  jf=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input1));
  mf=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input2));
  af=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input3));
  jt=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input4));
  mt=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input5));
  at=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input6));


  sprintf (h.from,"%d/%d/%d",jf,mf,af);
  sprintf (h.to,"%d/%d/%d",jt,mt,at);
/****************************FROM TO spin button****************************************************************/
 input7=lookup_widget(objet,"nounH") ;
 input8=lookup_widget(objet,"locationH") ;
 strcpy(h.noun,gtk_entry_get_text(GTK_ENTRY(input7)));
 strcpy(h.location,gtk_entry_get_text(GTK_ENTRY(input8)));
 
  combobox1=lookup_widget(objet, "combobox1") ;
  if(strcmp("4 stars",gtk_combo_box_get_active_text(GTK_COMBO(combobox1)))==0)
  strcpy(h.starsNumber,"4_stars");
  else
  strcpy(h.starsNumber,"5_stars"); 

  
  f=fopen("hotel.txt","a+");
  if (f!=NULL)
{
  fprintf(f,"%s %s %s %s %s\n",h.noun,h.location,h.starsNumber,h.from,h.to);
  fclose(f);
}
}
void afficherhotel (GtkListItem *liste)
{
  GtkCellRenderer *renderer;
  GtkTreeViewColumn *column;
  GtkTreeIter iter;
  GtkListStore *store;
  int jf,mf,af,jt,mt,at;
  GtkWidget *input1 ,*input2,*input3,*input4,*input5,*input6;
  char noun[20];
  char location[20];
  char starsNumber[20];
  char from[20];
  char to[20];
  store=NULL;
  
           FILE*f;
     
     store=gtk_tree_view_get_model(liste);
           if(store==NULL)
{
          renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes(" noun",renderer,"text",NOUN, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
          renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes(" location",renderer,"text",LOCATION, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
          renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes(" starsNumber",renderer,"text",STARSNUMBER, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
          renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes(" from",renderer,"text",FROM, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
           renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes(" to",renderer,"text",TO, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
      store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
      f= fopen("hotel.txt","r");
      if(f==NULL)
        {
                return;
        }
     else 
       {
          f= fopen("hotel.txt","a+");
                    while(fscanf(f,"%s %s %s %s %s\n",noun,location,starsNumber,from,to)!=EOF)
            {
     gtk_list_store_append (store, &iter);
     gtk_list_store_set (store, &iter, NOUN, noun, LOCATION, location, STARSNUMBER, starsNumber, FROM, from, TO, to, -1); 
            }
              fclose(f);
       gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
       g_object_unref (store);
       }
}
}

void supprimerhotel(char location[],char noun[])
{	Hotel h;
	FILE *f=NULL;
	FILE *ftemp;
	f=fopen("hotel.txt","r");    
	ftemp=fopen("ftemp.txt","w");
	fclose(ftemp);
	ftemp=fopen("ftemp.txt","a+");
	if (f!=NULL)
	while(fscanf(f,"%s %s %s %s %s\n",h.noun,h.location,h.starsNumber,h.from,h.to)!=EOF)
    	{g_print("\nNom jey %s     Nom mawjoud %s",noun,h.noun);
        	if(strcmp(h.location,location)!=0 && strcmp(h.noun,noun)!=0)
        		{
            			fprintf(ftemp,"%s %s %s %s %s\n",h.noun,h.location,h.starsNumber,h.from,h.to);
        		}
        
        
    	}

    
    	fclose(f);
    	fclose(ftemp);
    	remove("/home/houssem123/Projects/Sofien2/src/hotel.txt");
    	rename("/home/houssem123/Projects/Sofien2/src/ftemp.txt","/home/houssem123/Projects/Sofien2/src/hotel.txt");
    }





