#include <gtk/gtk.h>
#include "user.h" 
#include <string.h>
#include <stdlib.h>
void ajouterAgent(GtkWidget       *objet){
User u;
char Role[20];
FILE *f;
GtkWidget *nominsc ,*prenomIns,*pseudonymeInsc,*emailInsc,*adresseInsc,*telephoneInsc,*passwordInsc;
 nominsc=lookup_widget(objet,"nominsc") ;
 prenomIns=lookup_widget(objet,"prenomIns");
 pseudonymeInsc=lookup_widget(objet,"pseudonymeInsc") ;
 emailInsc=lookup_widget(objet,"emailInsc") ;
 adresseInsc=lookup_widget(objet,"adresseInsc") ;
 telephoneInsc=lookup_widget(objet,"telephoneInsc") ;
 passwordInsc=lookup_widget(objet,"passwordInsc") ;
 strcpy(u.pseudonyme,gtk_entry_get_text(GTK_ENTRY(pseudonymeInsc)));
 strcpy(u.nom,gtk_entry_get_text(GTK_ENTRY(nominsc)));
 strcpy(u.prenom,gtk_entry_get_text(GTK_ENTRY(prenomIns)));
 strcpy(u.email,gtk_entry_get_text(GTK_ENTRY(emailInsc)));
 strcpy(u.adresse,gtk_entry_get_text(GTK_ENTRY(adresseInsc)));
 strcpy(u.telephone,gtk_entry_get_text(GTK_ENTRY(telephoneInsc)));
 strcpy(u.password,gtk_entry_get_text(GTK_ENTRY(passwordInsc)));
 u.role=1;
 f=fopen("user.txt","a+");
  if (f!=NULL)
{
  g_print("%s %s %s %s %s %s %s %d\n",u.pseudonyme,u.nom,u.prenom,u.password,u.email,u.adresse,u.telephone,u.role);
  fprintf(f,"%s %s %s %s %s %s %s %d\n",u.pseudonyme,u.nom,u.prenom,u.password,u.email,u.adresse,u.telephone,u.role);
  fclose(f);
}

}
void ajouterClient(GtkWidget       *objet){
User u;
char Role[20];
FILE *f;
GtkWidget *nominsc1 ,*prenomIns1,*pseudonymeInsc1,*emailInsc1,*adresseInsc1,*telephoneInsc1,*passwordInsc1;
 nominsc1=lookup_widget(objet,"nominsc1") ;
 prenomIns1=lookup_widget(objet,"prenomIns1");
 pseudonymeInsc1=lookup_widget(objet,"pseudonymeInsc1") ;
 emailInsc1=lookup_widget(objet,"emailInsc1") ;
 adresseInsc1=lookup_widget(objet,"adresseInsc1") ;
 telephoneInsc1=lookup_widget(objet,"telephoneInsc1") ;
 passwordInsc1=lookup_widget(objet,"passwordInsc1") ;
 strcpy(u.pseudonyme,gtk_entry_get_text(GTK_ENTRY(pseudonymeInsc1)));
 strcpy(u.nom,gtk_entry_get_text(GTK_ENTRY(nominsc1)));
 strcpy(u.prenom,gtk_entry_get_text(GTK_ENTRY(prenomIns1)));
 strcpy(u.email,gtk_entry_get_text(GTK_ENTRY(emailInsc1)));
 strcpy(u.adresse,gtk_entry_get_text(GTK_ENTRY(adresseInsc1)));
 strcpy(u.telephone,gtk_entry_get_text(GTK_ENTRY(telephoneInsc1)));
 strcpy(u.password,gtk_entry_get_text(GTK_ENTRY(passwordInsc1)));
 u.role=2;
 f=fopen("user.txt","a+");
  if (f!=NULL)
{
  g_print("%s %s %s %s %s %s %s %d\n",u.pseudonyme,u.nom,u.prenom,u.password,u.email,u.adresse,u.telephone,u.role);
  fprintf(f,"%s %s %s %s %s %s %s %d\n",u.pseudonyme,u.nom,u.prenom,u.password,u.email,u.adresse,u.telephone,u.role);
  fclose(f);
}

}
User getUser(char Pseudo[20],char passw[20]){
User u;
GtkWidget *Acceuil,*login;
FILE *f;
f= fopen("user.txt","a+");
              while(fscanf(f,"%s %s %s %s %s %s %s %d",u.pseudonyme,u.nom,u.prenom,u.password,u.email,u.adresse,u.telephone,&u.role)!=EOF)
            {
		g_printf("%s %s %s %s %s %s %s %d\n",u.pseudonyme,u.nom,u.prenom,u.password,u.email,u.adresse,u.telephone,u.role);
		g_printf("%s %s\n",Pseudo,passw);
		g_printf("email : %s password : %s\n",u.pseudonyme,u.password);
		if (strcmp(Pseudo,u.pseudonyme)==0 && strcmp(passw,u.password)==0)
		return u;
	    }
}
