#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "hotel.h"
#include "reservation.h"

Reservation reservationSelected;
Hotel hotel_selectioner;
Offre hotelSelected;

void
on_housing_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *providerOffers;
GtkWidget *housingChoice;

housingChoice=create_housingChoice ();
providerOffers=lookup_widget(objet,"providerOffers");
gtk_widget_destroy(providerOffers);
gtk_widget_show(housingChoice);


}


void
on_hotel_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *housingChoice;
GtkWidget *inscriptionHotel;
housingChoice=lookup_widget(objet,"housingChoice");
  gtk_widget_destroy(housingChoice);
  inscriptionHotel=lookup_widget(objet,"inscriptionHotel");
  inscriptionHotel=create_inscriptionHotel();
   gtk_widget_show(inscriptionHotel);
/*GtkWidget *housingChoice;
GtkWidget *hotelOffers;
housingChoice=lookup_widget(objet,"housingChoice");
  gtk_widget_destroy(housingChoice);
  hotelOffers=lookup_widget(objet,"hotelOffers");
  hotelOffers=create_hotelOffers();
   gtk_widget_show(hotelOffers);*/

}


void
on_consultHotel_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *hotelOffers ;
GtkWidget *listehotel ;
GtkWidget *treeview1;
hotelOffers=lookup_widget(objet,"hotelOffers");
  gtk_widget_destroy(hotelOffers);
  //listehotel=lookup_widget(objet,"listehotel");
  listehotel=create_listehotel();
   gtk_widget_show(listehotel);
treeview1=lookup_widget(listehotel,"treeview1");



afficherhotel(treeview1);


}


void
on_homehotel_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
/*GtkWidget *hotelOffers;
GtkWidget *providerOffers;
hotelOffers=lookup_widget(objet,"hotelOffers");
  gtk_widget_destroy(hotelOffers);
  providerOffers=lookup_widget(objet,"providerOffers");
  providerOffers=create_providerOffers();
   gtk_widget_show(providerOffers);*/

}


void
on_addHotel_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{ 

//ajoutHotel(objet);



}


void
on_returnListeHotel_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
/*GtkWidget *listehotel;
GtkWidget *hotelOffers;
listehotel=lookup_widget(objet,"listehotel");
  gtk_widget_destroy(listehotel);
  hotelOffers=lookup_widget(objet,"hotelOffers");
  hotelOffers=create_hotelOffers();
   gtk_widget_show(hotelOffers);*/






}




void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
/*gchar *str_data;
gchar *str_data1;
GtkListStore *list_store;
list_store=gtk_tree_view_get_model(treeview);
GtkTreeIter   iter;
  if (gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store), &iter, path))
  { 
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 0, &str_data, -1);
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 1, &str_data1, -1);
  }

strcpy(hotel_selectioner.noun,str_data);
strcpy(hotel_selectioner.location,str_data1);

FILE *f ;
f=fopen("hotel.txt","r");
struct Hotel h;
while (fscanf(f,"%s %s %s %s %s\n",h.noun,h.location,h.starsNumber,h.from,h.to)!=EOF)
{

if (strcmp(hotel_selectioner.noun,h.noun)==0 || strcmp(hotel_selectioner.location,h.location)==0 ) hotel_selectioner=h;

}



fclose(f);*/
}



void
on_deleteHotel_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
/*GtkWidget *point,*listehotel;
g_print("\n%s      %s",hotel_selectioner.noun,hotel_selectioner.location);
supprimerhotel(hotel_selectioner.location,hotel_selectioner.noun);
listehotel=lookup_widget(objet,"listehotel");
gtk_widget_destroy(listehotel);
listehotel=create_listehotel();
point=lookup_widget(listehotel,"treeview1");
afficherhotel(point);
gtk_widget_show(listehotel);
gtk_widget_show(point);*/


}


void
on_modifh_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data)
{
/*GtkWidget *a,*b,*l,*l1,*List_View ;
   

	Hotel h ;
	
	supprimerhotel(hotel_selectioner.location,hotel_selectioner.noun);
	a=lookup_widget(objet,"entry1");
	b=lookup_widget(objet,"entry2");
	strcpy(hotel_selectioner.noun,gtk_entry_get_text(GTK_ENTRY(a)));
	strcpy(hotel_selectioner.location,gtk_entry_get_text(GTK_ENTRY(b)));
 
        FILE *f;
  
  f=fopen("hotel.txt","a+");
  if (f!=NULL)
{
fprintf(f,"%s %s %s %s %s\n",hotel_selectioner.noun,hotel_selectioner.location,hotel_selectioner.starsNumber,hotel_selectioner.from,hotel_selectioner.to);
  fclose(f);
	l=create_listehotel();

	l1=lookup_widget(objet,"modifierhotel");
	gtk_widget_destroy(l1);

	List_View=lookup_widget(l,"treeview1");
	afficherhotel(List_View);
	gtk_widget_show (l);


}
*/


}


void
on_modifyyy_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
/*GtkWidget *listehotel;
GtkWidget *modifierhotel;
GtkWidget *out;

modifierhotel=create_modifierhotel();

listehotel=lookup_widget(objet,"listehotel");
gtk_widget_destroy(listehotel);
gtk_widget_show(modifierhotel);
out=lookup_widget(modifierhotel,"entry1");
gtk_entry_set_text (out,hotel_selectioner.noun);
out=lookup_widget(modifierhotel,"entry2");
gtk_entry_set_text (out,hotel_selectioner.location);

*/

}


void
on_Inscription_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{

GtkWidget *Acceuil,*ajouter;
Acceuil=lookup_widget(objet,"login");
gtk_widget_destroy(Acceuil);
ajouter=lookup_widget(objet,"inscriptionClient");
ajouter=create_inscriptionClient();
gtk_widget_show(ajouter);
}


void
on_AjouterAgent_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *Acceuil,*ajouter;
Acceuil=lookup_widget(objet,"AdminAcceuil");
gtk_widget_destroy(Acceuil);
ajouter=lookup_widget(objet,"inscriptionAgent");
ajouter=create_inscriptionAgent();
gtk_widget_show(ajouter);

}


void
on_Login_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data)
{

GtkWidget *Pseudo,*Mdp;
char P[20],M[20];
User u;
FILE *f;
GtkWidget *Acceuil,*login;
Pseudo=lookup_widget(objet,"PseudonymeLogin");
Mdp=lookup_widget(objet,"mdpLogin");
strcpy(P,gtk_entry_get_text(GTK_ENTRY(Pseudo)));
strcpy(M,gtk_entry_get_text(GTK_ENTRY(Mdp)));
u=getUser(P,M);
if (u.nom!=""){
if (u.role==0){
		login=lookup_widget(objet,"login");
  		gtk_widget_destroy(login);
  		Acceuil=lookup_widget(objet,"AdminAcceuil");
  		Acceuil=create_AdminAcceuil();
   		gtk_widget_show(Acceuil);
remove("/home/houssem123/Projects/Sofien2/src/userConnected.txt");
f=fopen("userConnected.txt","a+");
  if (f!=NULL)
{
  g_print("%s %s %s %s %s %s %s %d\n",u.pseudonyme,u.nom,u.prenom,u.password,u.email,u.adresse,u.telephone,u.role);
  fprintf(f,"%s %s %s %s %s %s %s %d\n",u.pseudonyme,u.nom,u.prenom,u.password,u.email,u.adresse,u.telephone,u.role);
  fclose(f);
}


}
if (u.role==1){
		login=lookup_widget(objet,"login");
  		gtk_widget_destroy(login);
  		Acceuil=lookup_widget(objet,"providerOffers");
  		Acceuil=create_providerOffers();
   		gtk_widget_show(Acceuil);

remove("/home/houssem123/Projects/Sofien2/src/userConnected.txt");
f=fopen("userConnected.txt","a+");
  if (f!=NULL)
{
  g_print("%s %s %s %s %s %s %s %d\n",u.pseudonyme,u.nom,u.prenom,u.password,u.email,u.adresse,u.telephone,u.role);
  fprintf(f,"%s %s %s %s %s %s %s %d\n",u.pseudonyme,u.nom,u.prenom,u.password,u.email,u.adresse,u.telephone,u.role);
  fclose(f);
}
}
if (u.role==2){
		login=lookup_widget(objet,"login");
  		gtk_widget_destroy(login);
  		Acceuil=lookup_widget(objet,"AccueilClient");
  		Acceuil=create_AccueilClient();
   		gtk_widget_show(Acceuil);

remove("/home/houssem123/Projects/Sofien2/src/userConnected.txt");
f=fopen("userConnected.txt","a+");
  if (f!=NULL)
{
  g_print("%s %s %s %s %s %s %s %d\n",u.pseudonyme,u.nom,u.prenom,u.password,u.email,u.adresse,u.telephone,u.role);
  fprintf(f,"%s %s %s %s %s %s %s %d\n",u.pseudonyme,u.nom,u.prenom,u.password,u.email,u.adresse,u.telephone,u.role);
  fclose(f);
}
}





}
else{
g_print("Non connecté");
}
}


void
on_AjouterAgentInsc_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
ajouterAgent(objet);
GtkWidget *Acceuil,*ajouter;
Acceuil=lookup_widget(objet,"inscriptionAgent");
gtk_widget_destroy(Acceuil);
ajouter=lookup_widget(objet,"AdminAcceuil");
ajouter=create_AdminAcceuil();
gtk_widget_show(ajouter);
}


void
on_AjouterHotel_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
ajoutHotel(objet);

}


void
on_AfficherHotel_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *inscriptionHotel ;
GtkWidget *AfficherHotel ;
GtkWidget *HotelTree;
inscriptionHotel=lookup_widget(objet,"inscriptionHotel");
 gtk_widget_destroy(inscriptionHotel);
  //listehotel=lookup_widget(objet,"listehotel");
  AfficherHotel=create_AfficherHotel();
   gtk_widget_show(AfficherHotel);
HotelTree=lookup_widget(AfficherHotel,"HotelTree");



aff(HotelTree);

}


void
on_HomeHotel_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{

}


void
on_Supprimer_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *point,*listehotel;

supphotel(hotelSelected.id);
listehotel=lookup_widget(objet,"AfficherHotel");
gtk_widget_destroy(listehotel);
listehotel=create_AfficherHotel();
point=lookup_widget(listehotel,"HotelTree");
aff(point);
gtk_widget_show(listehotel);
gtk_widget_show(point);
}




void
on_Retour_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data)
{

}



void
on_HotelTree_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
gchar *str_data;
gchar *str_data1;
GtkListStore *list_store;
list_store=gtk_tree_view_get_model(treeview);
GtkTreeIter   iter;
  if (gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store), &iter, path))
  { 
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 0, &str_data, -1);
  }
g_print(str_data);

strcpy(hotelSelected.id,str_data);

FILE *f ;
f=fopen("offreLocal.txt","r");
struct Offre o;
while (fscanf(f,"%s %s %s %s %s %s %s %s %d %s\n",o.id,o.nomOffre,o.adresse,o.prix,o.from,o.to,o.nombre_etoile,o.nombre_chambre,&o.type,o.agent)!=EOF)
{

if (strcmp(hotelSelected.id,o.id)==0)
hotelSelected=o;

}



fclose(f);

}


void
on_hom_clicked                         (GtkWidget       *objet,
                                        gpointer         user_data)
{

}


void
on_modifierHotel_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *a,*b,*c,*d,*l,*l1,*List_View,*HotelTree ;
   

	Hotel h ;
	
	supphotel(hotelSelected.id);
	a=lookup_widget(objet,"nomModifHotel");
	b=lookup_widget(objet,"adressemodifHotel");
	c=lookup_widget(objet,"prixModifHotel");
	d=lookup_widget(objet,"modifNombreHotel");
	strcpy(hotelSelected.nomOffre,gtk_entry_get_text(GTK_ENTRY(a)));
	strcpy(hotelSelected.adresse,gtk_entry_get_text(GTK_ENTRY(b)));
	strcpy(hotelSelected.prix,gtk_entry_get_text(GTK_ENTRY(c)));
	strcpy(hotelSelected.nombre_etoile,gtk_entry_get_text(GTK_ENTRY(d)));
 
        FILE *f;
  
  f=fopen("offreLocal.txt","a+");
  if (f!=NULL)
{
fprintf(f,"%s %s %s %s %s %s %s %s %d %s\n",hotelSelected.id,hotelSelected.nomOffre,hotelSelected.adresse,hotelSelected.prix,hotelSelected.from,hotelSelected.to,hotelSelected.nombre_etoile,hotelSelected.nombre_chambre,hotelSelected.type,hotelSelected.agent);
  fclose(f);
	l=create_AfficherHotel();

	l1=lookup_widget(objet,"modificationHotel");
	gtk_widget_destroy(l1);


HotelTree=lookup_widget(l,"HotelTree");
aff(HotelTree);
	gtk_widget_show (l);
}

}
void
on_modifierHotelRedirect_clicked       (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *listehotel;
GtkWidget *modifierhotel;
GtkWidget *out;

modifierhotel=create_modificationHotel();

char* token; 
char* rest = hotelSelected.from;
char* rest1 = hotelSelected.to;
int tab[6]; 
int i=0;
int j=3;

/*while ((token = strtok_r(rest1, "/", &rest1))) 
      {g_print("%s\n", token); 
	tab[j]=atoi(token);	
	j++;	
	}*/
  
g_print("offre selectionner :%s %s %s",hotelSelected.nomOffre,hotelSelected.adresse,hotelSelected.prix);
listehotel=lookup_widget(objet,"AfficherHotel");
gtk_widget_destroy(listehotel);
gtk_widget_show(modifierhotel);
out=lookup_widget(modifierhotel,"nomModifHotel");
gtk_entry_set_text (out,hotelSelected.nomOffre);
out=lookup_widget(modifierhotel,"adressemodifHotel");
gtk_entry_set_text (out,hotelSelected.adresse);
out=lookup_widget(modifierhotel,"prixModifHotel");
gtk_entry_set_text (out,hotelSelected.prix);
out=lookup_widget(modifierhotel,"modifNombreHotel");
gtk_entry_set_text (out,hotelSelected.nombre_etoile);
/*out=lookup_widget(modifierhotel,"spinbutton7");
gtk_entry_set_text (out,tab[0]);
out=lookup_widget(modifierhotel,"spinbutton8");
gtk_entry_set_text (out,tab[1]);
out=lookup_widget(modifierhotel,"spinbutton9");
gtk_entry_set_text (out,tab[2]);
/*out=lookup_widget(modifierhotel,"spinbutton10");
gtk_entry_set_text (out,tab[3]);
out=lookup_widget(modifierhotel,"spinbutton11");
gtk_entry_set_text (out,tab[4]);
out=lookup_widget(modifierhotel,"spinbutton12");
gtk_entry_set_text (out,tab[5]);*/

}
/*******************************************************************************************************************************************/

void
on_HomeMotel_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{

}


void
on_AfficherMotel_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *inscriptionMotel ;
GtkWidget *AfficherMotel ;
GtkWidget *MotelTree;
inscriptionMotel=lookup_widget(objet,"inscriptionMotel");
 gtk_widget_destroy(inscriptionMotel);
  //listehotel=lookup_widget(objet,"listehotel");
  AfficherMotel=create_AfficherMotel();
   gtk_widget_show(AfficherMotel);
MotelTree=lookup_widget(AfficherMotel,"MotelTree");



affMotel(MotelTree);


}


void
on_AjouterMotel_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
 ajoutMotel(objet);

}


void
on_hom1_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data)
{

}


void
on_supprimerMotelRedirect_clicked      (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *point,*listeMotel;

suppMotel(hotelSelected.id);
listeMotel=lookup_widget(objet,"AfficherMotel");
gtk_widget_destroy(listeMotel);
listeMotel=create_AfficherMotel();
point=lookup_widget(listeMotel,"MotelTree");
affMotel(point);
gtk_widget_show(listeMotel);
gtk_widget_show(point);

}


void
on_modifierMotelRedirect_clicked       (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *listeMotel;
GtkWidget *modifierMotel;
GtkWidget *out;

modifierMotel=create_modificationMotel();

char* token; 
char* rest = hotelSelected.from;
char* rest1 = hotelSelected.to;
int tab[6]; 
int i=0;
int j=3;

/*while ((token = strtok_r(rest1, "/", &rest1))) 
      {g_print("%s\n", token); 
	tab[j]=atoi(token);	
	j++;	
	}*/
  
g_print("offre selectionner :%s %s %s",hotelSelected.nomOffre,hotelSelected.adresse,hotelSelected.prix);
listeMotel=lookup_widget(objet,"AfficherMotel");
gtk_widget_destroy(listeMotel);
gtk_widget_show(modifierMotel);
out=lookup_widget(modifierMotel,"nomModifMotel");
gtk_entry_set_text (out,hotelSelected.nomOffre);
out=lookup_widget(modifierMotel,"adressemodifMotel");
gtk_entry_set_text (out,hotelSelected.adresse);
out=lookup_widget(modifierMotel,"prixModifMotel");
gtk_entry_set_text (out,hotelSelected.prix);
out=lookup_widget(modifierMotel,"modifNombreMotel");
gtk_entry_set_text (out,hotelSelected.nombre_chambre);
}


void
on_modifierMotel_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *a,*b,*c,*d,*l,*l1,*List_View,*MotelTree ;
   

	Hotel h ;
	
	suppMotel(hotelSelected.id);
	a=lookup_widget(objet,"nomModifMotel");
	b=lookup_widget(objet,"adressemodifMotel");
	c=lookup_widget(objet,"prixModifMotel");
	d=lookup_widget(objet,"modifNombreMotel");
	strcpy(hotelSelected.nomOffre,gtk_entry_get_text(GTK_ENTRY(a)));
	strcpy(hotelSelected.adresse,gtk_entry_get_text(GTK_ENTRY(b)));
	strcpy(hotelSelected.prix,gtk_entry_get_text(GTK_ENTRY(c)));
	strcpy(hotelSelected.nombre_chambre,gtk_entry_get_text(GTK_ENTRY(d)));
 
        FILE *f;
  
  f=fopen("offreLocal.txt","a+");
  if (f!=NULL)
{
fprintf(f,"%s %s %s %s %s %s %s %s %d %s\n",hotelSelected.id,hotelSelected.nomOffre,hotelSelected.adresse,hotelSelected.prix,hotelSelected.from,hotelSelected.to,hotelSelected.nombre_etoile,hotelSelected.nombre_chambre,hotelSelected.type,hotelSelected.agent);
  fclose(f);
	l=create_AfficherMotel();

	l1=lookup_widget(objet,"modificationMotel");
	gtk_widget_destroy(l1);


MotelTree=lookup_widget(l,"MotelTree");
affMotel(MotelTree);
	gtk_widget_show (l);
}

}
/*******************************************************************************************************************************************/



void
on_modifierHRentalRedirect_clicked     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *listeHRental;
GtkWidget *modifierHRental;
GtkWidget *out;

modifierHRental=create_modificationHRental();

char* token; 
char* rest = hotelSelected.from;
char* rest1 = hotelSelected.to;
int tab[6]; 
int i=0;
int j=3;

/*while ((token = strtok_r(rest1, "/", &rest1))) 
      {g_print("%s\n", token); 
	tab[j]=atoi(token);	
	j++;	
	}*/
  
g_print("offre selectionner :%s %s %s",hotelSelected.nomOffre,hotelSelected.adresse,hotelSelected.prix);
listeHRental=lookup_widget(objet,"AfficherHouseRental");
gtk_widget_destroy(listeHRental);
gtk_widget_show(modifierHRental);
out=lookup_widget(modifierHRental,"nomModifHRental");
gtk_entry_set_text (out,hotelSelected.nomOffre);
out=lookup_widget(modifierHRental,"adressemodifHRental");
gtk_entry_set_text (out,hotelSelected.adresse);
out=lookup_widget(modifierHRental,"prixModifHRental");
gtk_entry_set_text (out,hotelSelected.prix);
out=lookup_widget(modifierHRental,"modifNombreHRental");
gtk_entry_set_text (out,hotelSelected.nombre_chambre);

}


void
on_supprimerHRentalRedirect_clicked    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *point,*listeHRental;

suppHRental(hotelSelected.id);
listeHRental=lookup_widget(objet,"AfficherHouseRental");
gtk_widget_destroy(listeHRental);
listeHRental=create_AfficherHouseRental();
point=lookup_widget(listeHRental,"HRentalTree");
affMotel(point);
gtk_widget_show(listeHRental);
gtk_widget_show(point);


}


void
on_retourHRentalRedirect_clicked       (GtkWidget       *objet,
                                        gpointer         user_data)
{

}


void
on_hom2_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data)
{

}


void
on_modifierHrental_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{

GtkWidget *a,*b,*c,*d,*l,*l1,*List_View,*HRentalTree ;
   

	Hotel h ;
	
	suppMotel(hotelSelected.id);
	a=lookup_widget(objet,"nomModifHRental");
	b=lookup_widget(objet,"adressemodifHRental");
	c=lookup_widget(objet,"prixModifHRental");
	d=lookup_widget(objet,"modifNombreHRental");
	strcpy(hotelSelected.nomOffre,gtk_entry_get_text(GTK_ENTRY(a)));
	strcpy(hotelSelected.adresse,gtk_entry_get_text(GTK_ENTRY(b)));
	strcpy(hotelSelected.prix,gtk_entry_get_text(GTK_ENTRY(c)));
	strcpy(hotelSelected.nombre_chambre,gtk_entry_get_text(GTK_ENTRY(d)));
 
        FILE *f;
  
  f=fopen("offreLocal.txt","a+");
  if (f!=NULL)
{
fprintf(f,"%s %s %s %s %s %s %s %s %d %s\n",hotelSelected.id,hotelSelected.nomOffre,hotelSelected.adresse,hotelSelected.prix,hotelSelected.from,hotelSelected.to,hotelSelected.nombre_etoile,hotelSelected.nombre_chambre,hotelSelected.type,hotelSelected.agent);
  fclose(f);
	l=create_AfficherHouseRental();

	l1=lookup_widget(objet,"modificationHRental");
	gtk_widget_destroy(l1);


HRentalTree=lookup_widget(l,"HRentalTree");
affHRental(HRentalTree);
	gtk_widget_show (l);
}

}


void
on_AjouterHouseRental_clicked          (GtkWidget       *objet,
                                        gpointer         user_data)
{
 ajoutHRental(objet);
}


void
on_AfficherHouseRental_clicked         (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *inscriptionHouseRental ;
GtkWidget *AfficherHouseRental ;
GtkWidget *HRentalTree;
inscriptionHouseRental=lookup_widget(objet,"inscriptionHouseRental");
 gtk_widget_destroy(inscriptionHouseRental);
  //listehotel=lookup_widget(objet,"listehotel");
  AfficherHouseRental=create_AfficherHouseRental();
   gtk_widget_show(AfficherHouseRental);
HRentalTree=lookup_widget(AfficherHouseRental,"HRentalTree");



affHRental(HRentalTree);

}


void
on_HomeHouseRental_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{

}
/******************************************************************************************************************************************/

void
on_AjouterGHouse_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
ajoutGHouse(objet);
}


void
on_HomeGhouse_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{

}


void
on_AfficherGhouse_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *inscriptionGHouse ;
GtkWidget *AfficherGHouse ;
GtkWidget *GHouseTree;
inscriptionGHouse=lookup_widget(objet,"inscriptionGHouse");
 gtk_widget_destroy(inscriptionGHouse);
  //listehotel=lookup_widget(objet,"listehotel");
  AfficherGHouse=create_AfficherGHouse();
   gtk_widget_show(AfficherGHouse);
GHouseTree=lookup_widget(AfficherGHouse,"GHouseTree");



affHRental(GHouseTree);

}


void
on_modifierGHouseRedirect_clicked      (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *listeGHouse;
GtkWidget *modifierGHouse;
GtkWidget *out;

modifierGHouse=create_modificationGHouse();

char* token; 
char* rest = hotelSelected.from;
char* rest1 = hotelSelected.to;
int tab[6]; 
int i=0;
int j=3;

/*while ((token = strtok_r(rest1, "/", &rest1))) 
      {g_print("%s\n", token); 
	tab[j]=atoi(token);	
	j++;	
	}*/
  
g_print("offre selectionner :%s %s %s",hotelSelected.nomOffre,hotelSelected.adresse,hotelSelected.prix);
listeGHouse=lookup_widget(objet,"AfficherGHouse");
gtk_widget_destroy(listeGHouse);
gtk_widget_show(modifierGHouse);
out=lookup_widget(modifierGHouse,"nomModifGHouse");
gtk_entry_set_text (out,hotelSelected.nomOffre);
out=lookup_widget(modifierGHouse,"adressemodifGHouse");
gtk_entry_set_text (out,hotelSelected.adresse);
out=lookup_widget(modifierGHouse,"prixModifGHouse");
gtk_entry_set_text (out,hotelSelected.prix);
out=lookup_widget(modifierGHouse,"modifNombreGHouse");
gtk_entry_set_text (out,hotelSelected.nombre_chambre);

}


void
on_supprimerGHouseRedirect_clicked     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *point,*listeGHouse;

suppGHouse(hotelSelected.id);
listeGHouse=lookup_widget(objet,"AfficherGHouse");
gtk_widget_destroy(listeGHouse);
listeGHouse=create_AfficherGHouse();
point=lookup_widget(listeGHouse,"GHouseTree");
affMotel(point);
gtk_widget_show(listeGHouse);
gtk_widget_show(point);

}


void
on_hom3_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data)
{

}


void
on_modifierGHouse_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{

GtkWidget *a,*b,*c,*d,*l,*l1,*List_View,*GHouseTree ;
   

	Hotel h ;
	
	suppGHouse(hotelSelected.id);
	a=lookup_widget(objet,"nomModifGHouse");
	b=lookup_widget(objet,"adressemodifGHouse");
	c=lookup_widget(objet,"prixModifGHouse");
	d=lookup_widget(objet,"modifNombreGHouse");
	strcpy(hotelSelected.nomOffre,gtk_entry_get_text(GTK_ENTRY(a)));
	strcpy(hotelSelected.adresse,gtk_entry_get_text(GTK_ENTRY(b)));
	strcpy(hotelSelected.prix,gtk_entry_get_text(GTK_ENTRY(c)));
	strcpy(hotelSelected.nombre_chambre,gtk_entry_get_text(GTK_ENTRY(d)));
 
        FILE *f;
  
  f=fopen("offreLocal.txt","a+");
  if (f!=NULL)
{
fprintf(f,"%s %s %s %s %s %s %s %s %d %s\n",hotelSelected.id,hotelSelected.nomOffre,hotelSelected.adresse,hotelSelected.prix,hotelSelected.from,hotelSelected.to,hotelSelected.nombre_etoile,hotelSelected.nombre_chambre,hotelSelected.type,hotelSelected.agent);
  fclose(f);
	l=create_AfficherGHouse();

	l1=lookup_widget(objet,"modificationGHouse");
	gtk_widget_destroy(l1);


GHouseTree=lookup_widget(l,"GHouseTree");
affGHouse(GHouseTree);
gtk_widget_show (l);

}
}

/*********************************************************************************************************************************************/



void
on_motell_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *housingChoice;
GtkWidget *inscriptionMotel;
housingChoice=lookup_widget(objet,"housingChoice");
  gtk_widget_destroy(housingChoice);
  inscriptionMotel=lookup_widget(objet,"inscriptionMotel");
  inscriptionMotel=create_inscriptionMotel();
   gtk_widget_show(inscriptionMotel);

}


void
on_house_rental_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *housingChoice;
GtkWidget *inscriptionHouseRental;
housingChoice=lookup_widget(objet,"housingChoice");
  gtk_widget_destroy(housingChoice);
  inscriptionHouseRental=lookup_widget(objet,"inscriptionHouseRental");
  inscriptionHouseRental=create_inscriptionHouseRental();
   gtk_widget_show(inscriptionHouseRental);

}


void
on_guest_house_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *housingChoice;
GtkWidget *inscriptionGHouse;
housingChoice=lookup_widget(objet,"housingChoice");
  gtk_widget_destroy(housingChoice);
  inscriptionGHouse=lookup_widget(objet,"inscriptionGHouse");
  inscriptionGHouse=create_inscriptionGHouse();
   gtk_widget_show(inscriptionGHouse);
}




void
on_AjouterClientInsc_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
ajouterClient(objet);
GtkWidget *Acceuil,*ajouter;
Acceuil=lookup_widget(objet,"inscriptionClient");
gtk_widget_destroy(Acceuil);
ajouter=lookup_widget(objet,"login");
ajouter=create_login();
gtk_widget_show(ajouter);
}


void
on_HousingClient_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *Acceuil,*reservation;
Acceuil=lookup_widget(objet,"AccueilClient");
gtk_widget_destroy(Acceuil);
reservation=lookup_widget(objet,"AccueilReservation");
reservation=create_AccueilReservation();
gtk_widget_show(reservation);

}


void
on_HotelClient_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *Acceuil,*reservation,*HotelTree;
Acceuil=lookup_widget(objet,"AccueilReservation");
gtk_widget_destroy(Acceuil);
reservation=lookup_widget(objet,"ReservationHotel");
reservation=create_ReservationHotel();
gtk_widget_show(reservation);
HotelTree=lookup_widget(reservation,"HotelClient");
affHotelClient(HotelTree);
}


void
on_MotelClient_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *Acceuil,*reservation,*MotelTree;
Acceuil=lookup_widget(objet,"AccueilReservation");
gtk_widget_destroy(Acceuil);
reservation=lookup_widget(objet,"ReservationMotel");
reservation=create_ReservationMotel();
gtk_widget_show(reservation);
MotelTree=lookup_widget(reservation,"MotelClient");
affMotelClient(MotelTree);

}


void
on_HouseClient_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *Acceuil,*reservation,*HouseTree;
Acceuil=lookup_widget(objet,"AccueilReservation");
gtk_widget_destroy(Acceuil);
reservation=lookup_widget(objet,"ReservationHouse");
reservation=create_ReservationHouse();
gtk_widget_show(reservation);
HouseTree=lookup_widget(reservation,"HotelClient");
affHRentalClient(HouseTree);

}


void
on_GHouseClient_activate               (GtkWidget       *objet,
                                        gpointer         user_data)
{GtkWidget *Acceuil,*reservation,*GHouseTree;
Acceuil=lookup_widget(objet,"AccueilReservation");
gtk_widget_destroy(Acceuil);
reservation=lookup_widget(objet,"ReservationGHouse");
reservation=create_ReservationGHouse();
gtk_widget_show(reservation);
GHouseTree=lookup_widget(reservation,"GHouseClient");
affGHouseClient(GHouseTree);

}


void
on_reserverHotel_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
ajouterReservationHotel(objet,hotelSelected.id);
}


void
on_ReserverMotel_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
ajouterReservationMotel(objet,hotelSelected.id);
}


void
on_reserverMaison_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
ajouterReservationHouse(objet,hotelSelected.id);
}


void
on_consulterReservation_clicked        (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *Acceuil,*consulter,*reservations;
Acceuil=lookup_widget(objet,"AccueilReservation");
gtk_widget_destroy(Acceuil);
consulter=lookup_widget(objet,"listeReservation");
consulter=create_listeReservation();
gtk_widget_show(consulter);
reservations=lookup_widget(consulter,"treeReservation");
affReserv(reservations);

}


void
on_reserverGHouse_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
ajouterReservationGHouse(objet,hotelSelected.id);

}



void
on_treeReservation_row_activated       (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
gchar *str_data;
gchar *str_data1;
GtkListStore *list_store;
list_store=gtk_tree_view_get_model(treeview);
GtkTreeIter   iter;
  if (gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store), &iter, path))
  { 
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 0, &str_data, -1);
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 1, &str_data1, -1);
  }
g_print(str_data);
g_print(str_data1);

strcpy(reservationSelected.pseudonyme,str_data);
strcpy(reservationSelected.id,str_data);

FILE *f ;
f=fopen("Reservation.txt","r");
struct Reservation r;
while (fscanf(f,"%s %s %s %s\n",r.pseudonyme,r.id,r.DateDebut,r.DateFin)!=EOF)
{

if ((strcmp(reservationSelected.id,r.id)==0)&&(strcmp(reservationSelected.pseudonyme,r.pseudonyme)==0))
reservationSelected=r;

}



fclose(f);


}


void
on_supprimerReservationClient_clicked  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *point,*listeGHouse;

suppreserv(reservationSelected.pseudonyme,reservationSelected.id);
listeGHouse=lookup_widget(objet,"listeReservation");
gtk_widget_destroy(listeGHouse);
listeGHouse=create_listeReservation();
point=lookup_widget(listeGHouse,"treeReservation");
affReserv(point);
gtk_widget_show(listeGHouse);
gtk_widget_show(point);
}

