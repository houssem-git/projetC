#include <gtk/gtk.h>
#include "Offre.h" 
#include <string.h>
#include <stdlib.h>
void ajoutHotel(GtkWidget       *objet){
Offre o;
Offre o2;
FILE *f;
g_print("ahla");
GtkWidget *nomOffreAjout,*AdresseAjout,*Prix,*nombredetoile,*spinbutton1,*spinbutton2,*spinbutton3,*spinbutton4,*spinbutton5,*spinbutton6;
nomOffreAjout=lookup_widget(objet,"nomOffreAjout") ;
AdresseAjout=lookup_widget(objet,"AdresseAjout");
Prix=lookup_widget(objet,"Prix") ;
nombredetoile=lookup_widget(objet,"nombredetoile") ;
spinbutton1=lookup_widget(objet,"spinbutton1") ;
spinbutton2=lookup_widget(objet,"spinbutton2") ;
spinbutton3=lookup_widget(objet,"spinbutton3") ;
spinbutton4=lookup_widget(objet,"spinbutton4") ;
spinbutton5=lookup_widget(objet,"spinbutton5") ;
spinbutton6=lookup_widget(objet,"spinbutton6") ;
int jf,mf,af,jt,mt,at;
jf=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton1));
mf=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton2));
af=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton3));
jt=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton4));
mt=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton5));
at=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton6));
sprintf (o.from,"%d/%d/%d",jf,mf,af);
sprintf (o.to,"%d/%d/%d",jt,mt,at);
strcpy(o.nomOffre,gtk_entry_get_text(GTK_ENTRY(nomOffreAjout)));
strcpy(o.adresse,gtk_entry_get_text(GTK_ENTRY(AdresseAjout)));
strcpy(o.prix,gtk_entry_get_text(GTK_ENTRY(Prix)));
strcpy(o.nombre_etoile,gtk_entry_get_text(GTK_ENTRY(nombredetoile)));
strcpy(o.nombre_chambre,"NULL");
o.type=0;
int nombreligne=1;

f=fopen("offreLocal.txt","r");
  if (f!=NULL)
{
  
 while(fscanf(f,"%d %s %s %s %s %s %s %s %d %s\n ",o2.id,o2.nomOffre,o2.adresse,o2.prix,o2.from,o2.to,o2.nombre_etoile,o2.nombre_chambre,&o2.type,o2.agent)!=EOF){
	nombreligne++;	
}
  fclose(f);
}
User u;
f=fopen("userConnected.txt","r");
  if (f!=NULL)
{
  
 while(fscanf(f,"%s %s %s %s %s %s %s %d",u.pseudonyme,u.nom,u.prenom,u.password,u.email,u.adresse,u.telephone,&u.role)!=EOF){	
}
  fclose(f);
}
sprintf (o.id,"%d",nombreligne);
strcpy(o.agent,u.pseudonyme);
f=fopen("offreLocal.txt","a+");
  if (f!=NULL)
{
  fprintf(f,"%s %s %s %s %s %s %s %s %d %s\n",o.id,o.nomOffre,o.adresse,o.prix,o.from,o.to,o.nombre_etoile,o.nombre_chambre,o.type,o.agent);
  g_print("%s %s %s %s %s %s %s %s %d %s\n",o.id,o.nomOffre,o.adresse,o.prix,o.from,o.to,o.nombre_etoile,o.nombre_chambre,o.type,o.agent);
  fclose(f);
}
}
enum{
ID,
NOM,
ADRESSE,
PRIX,
FROM,
TO,
NOMBRE_ETOILE,
NOMBRE_CHAMBRE,
COLUMNS
};
void aff (GtkListItem *liste)
{
  GtkCellRenderer *renderer;
  GtkTreeViewColumn *column;
  GtkTreeIter iter;
  GtkListStore *store;
char id[20];
char nomOffre[20];
char adresse[20];
char prix[20];
char from[20];
char to[20];
int type;
char nombre_etoile[20];
char nombre_chambre[20];
char agent[20];
  store=NULL;
  
           FILE*f;
     
     store=gtk_tree_view_get_model(liste);
           if(store==NULL)
{
	 renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("Identifiant",renderer,"text",ID, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
          renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("Nom",renderer,"text",NOM, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
 	  renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("Adresse",renderer,"text",ADRESSE, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
          renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("Prix",renderer,"text",PRIX, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
          renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("Date debut",renderer,"text",FROM, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
           renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("Date fin",renderer,"text",TO, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes(" nombre d'etoile",renderer,"text",NOMBRE_ETOILE, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
      store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING);
      f= fopen("offreLocal.txt","r");
      if(f==NULL)
        {
                return;
        }
     else 
       {
	 User u;
	  f=fopen("userConnected.txt","r");
 	 if (f!=NULL)
	{
  
 	while(fscanf(f,"%s %s %s %s %s %s %s %d",u.pseudonyme,u.nom,u.prenom,u.password,u.email,u.adresse,u.telephone,&u.role)!=EOF){	
	}
  	fclose(f);
	}
          f= fopen("offreLocal.txt","a+");
          while(fscanf(f,"%s %s %s %s %s %s %s %s %d %s\n",id,nomOffre,adresse,prix,from,to,nombre_etoile,nombre_chambre,&type,agent)!=EOF)
            {
		if(strcmp(u.pseudonyme,agent)==0 && type==0){
     gtk_list_store_append (store, &iter);
     gtk_list_store_set (store, &iter,ID,id, NOM,nomOffre, ADRESSE, adresse, PRIX, prix, FROM, from, TO, to, NOMBRE_ETOILE,nombre_etoile,-1); 
            }}
              fclose(f);
       gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
       g_object_unref (store);
       }
}
}



void supphotel(char id[20])
{	Offre o;
	FILE *f=NULL;
	FILE *ftemp;
	f=fopen("offreLocal.txt","r");    
	ftemp=fopen("ftemp.txt","w");
	fclose(ftemp);
	ftemp=fopen("ftemp.txt","a+");
	if (f!=NULL)
	 while(fscanf(f,"%s %s %s %s %s %s %s %s %d %s\n",o.id,o.nomOffre,o.adresse,o.prix,o.from,o.to,o.nombre_etoile,o.nombre_chambre,&o.type,o.agent)!=EOF)
    	{
        	if(strcmp(o.id,id)!=0)
        		{
            			fprintf(ftemp,"%s %s %s %s %s %s %s %s %d %s\n",o.id,o.nomOffre,o.adresse,o.prix,o.from,o.to,o.nombre_etoile,o.nombre_chambre,o.type,o.agent);
        		}
        
        
    	}

    
    	fclose(f);
    	fclose(ftemp);
    	remove("/home/houssem123/Projects/houssem_final!!/src/offreLocal.txt");
    	rename("/home/houssem123/Projects/houssem_final!!/src/ftemp.txt","/home/houssem123/Projects/houssem_final!!/src/offreLocal.txt");
 }

/*************************************************************Motel*******************************************************************/

void ajoutMotel(GtkWidget       *objet){
Offre o;
Offre o2;
FILE *f;
g_print("ahla");
GtkWidget *nomOffreAjout1,*AdresseAjout1,*Prix1,*nombreChambre,*spinbutton11,*spinbutton12,*spinbutton13,*spinbutton14,*spinbutton15,*spinbutton16;
nomOffreAjout1=lookup_widget(objet,"nomOffreAjout1") ;
AdresseAjout1=lookup_widget(objet,"AdresseAjout1");
Prix1=lookup_widget(objet,"Prix1") ;
nombreChambre=lookup_widget(objet,"nombreChambre") ;
spinbutton11=lookup_widget(objet,"spinbutton11") ;
spinbutton12=lookup_widget(objet,"spinbutton12") ;
spinbutton13=lookup_widget(objet,"spinbutton13") ;
spinbutton14=lookup_widget(objet,"spinbutton14") ;
spinbutton15=lookup_widget(objet,"spinbutton15") ;
spinbutton16=lookup_widget(objet,"spinbutton16") ;
int jf,mf,af,jt,mt,at;
jf=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton11));
mf=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton12));
af=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton13));
jt=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton14));
mt=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton15));
at=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton16));
sprintf (o.from,"%d/%d/%d",jf,mf,af);
sprintf (o.to,"%d/%d/%d",jt,mt,at);
strcpy(o.nomOffre,gtk_entry_get_text(GTK_ENTRY(nomOffreAjout1)));
strcpy(o.adresse,gtk_entry_get_text(GTK_ENTRY(AdresseAjout1)));
strcpy(o.prix,gtk_entry_get_text(GTK_ENTRY(Prix1)));
strcpy(o.nombre_chambre,gtk_entry_get_text(GTK_ENTRY(nombreChambre)));
strcpy(o.nombre_etoile,"NULL");
o.type=1;
int nombreligne=1;

f=fopen("offreLocal.txt","r");
  if (f!=NULL)
{
  
 while(fscanf(f,"%d %s %s %s %s %s %s %s %d %s\n ",o2.id,o2.nomOffre,o2.adresse,o2.prix,o2.from,o2.to,o2.nombre_etoile,o2.nombre_chambre,&o2.type,o2.agent)!=EOF){
	nombreligne++;	
}
  fclose(f);
}
User u;
f=fopen("userConnected.txt","r");
  if (f!=NULL)
{
  
 while(fscanf(f,"%s %s %s %s %s %s %s %d",u.pseudonyme,u.nom,u.prenom,u.password,u.email,u.adresse,u.telephone,&u.role)!=EOF){	
}
  fclose(f);
}
sprintf (o.id,"%d",nombreligne);
strcpy(o.agent,u.pseudonyme);
f=fopen("offreLocal.txt","a+");
  if (f!=NULL)
{
  fprintf(f,"%s %s %s %s %s %s %s %s %d %s\n",o.id,o.nomOffre,o.adresse,o.prix,o.from,o.to,o.nombre_etoile,o.nombre_chambre,o.type,o.agent);
  g_print("%s %s %s %s %s %s %s %s %d %s\n",o.id,o.nomOffre,o.adresse,o.prix,o.from,o.to,o.nombre_etoile,o.nombre_chambre,o.type,o.agent);
  fclose(f);
}
}

void affMotel (GtkListItem *liste)
{
  GtkCellRenderer *renderer;
  GtkTreeViewColumn *column;
  GtkTreeIter iter;
  GtkListStore *store;
char id[20];
char nomOffre[20];
char adresse[20];
char prix[20];
char from[20];
char to[20];
int type;
char nombre_etoile[20];
char nombre_chambre[20];
char agent[20];
  store=NULL;
  
           FILE*f;
     
     store=gtk_tree_view_get_model(liste);
           if(store==NULL)
{
	 renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("Identifiant",renderer,"text",ID, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
          renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("Nom",renderer,"text",NOM, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
 	  renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("Adresse",renderer,"text",ADRESSE, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
          renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("Prix",renderer,"text",PRIX, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
          renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("Date debut",renderer,"text",FROM, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
           renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("Date fin",renderer,"text",TO, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes(" nombre de chambre",renderer,"text",NOMBRE_CHAMBRE, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
      store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
      f= fopen("offreLocal.txt","r");
      if(f==NULL)
        {
                return;
        }
     else 
       {
	 User u;
	  f=fopen("userConnected.txt","r");
 	 if (f!=NULL)
	{
  
 	while(fscanf(f,"%s %s %s %s %s %s %s %d",u.pseudonyme,u.nom,u.prenom,u.password,u.email,u.adresse,u.telephone,&u.role)!=EOF){	
	}
  	fclose(f);
	}
          f= fopen("offreLocal.txt","a+");
          while(fscanf(f,"%s %s %s %s %s %s %s %s %d %s\n",id,nomOffre,adresse,prix,from,to,nombre_etoile,nombre_chambre,&type,agent)!=EOF)
            {
		if(strcmp(u.pseudonyme,agent)==0 && type==1){
     gtk_list_store_append (store, &iter);
     gtk_list_store_set (store, &iter,ID,id, NOM,nomOffre, ADRESSE, adresse, PRIX, prix, FROM, from, TO, to, NOMBRE_CHAMBRE,nombre_chambre,-1); 
            }}
              fclose(f);
       gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
       g_object_unref (store);
       }
}
}



void suppMotel(char id[20])
{	Offre o;
	FILE *f=NULL;
	FILE *ftemp;
	f=fopen("offreLocal.txt","r");    
	ftemp=fopen("ftemp.txt","w");
	fclose(ftemp);
	ftemp=fopen("ftemp.txt","a+");
	if (f!=NULL)
	 while(fscanf(f,"%s %s %s %s %s %s %s %s %d %s\n",o.id,o.nomOffre,o.adresse,o.prix,o.from,o.to,o.nombre_etoile,o.nombre_chambre,&o.type,o.agent)!=EOF)
    	{
        	if(strcmp(o.id,id)!=0)
        		{
            			fprintf(ftemp,"%s %s %s %s %s %s %s %s %d %s\n",o.id,o.nomOffre,o.adresse,o.prix,o.from,o.to,o.nombre_etoile,o.nombre_chambre,o.type,o.agent);
        		}
        
        
    	}

    
    	fclose(f);
    	fclose(ftemp);
    	remove("/home/houssem123/Projects/houssem_final!!/src/offreLocal.txt");
    	rename("/home/houssem123/Projects/houssem_final!!/src/ftemp.txt","/home/houssem123/Projects/houssem_final!!/src/offreLocal.txt");
 }
/*************************************************************************************************************************/
void ajoutHRental(GtkWidget       *objet){
Offre o;
Offre o2;
FILE *f;
g_print("ahla");
GtkWidget *nomOffreAjout2,*AdresseAjout2,*Prix2,*nombreChambre1,*spinbutton17,*spinbutton18,*spinbutton19,*spinbutton20,*spinbutton21,*spinbutton22;
nomOffreAjout2=lookup_widget(objet,"nomOffreAjout2") ;
AdresseAjout2=lookup_widget(objet,"AdresseAjout2");
Prix2=lookup_widget(objet,"Prix2") ;
nombreChambre1=lookup_widget(objet,"nombreChambre1") ;
spinbutton17=lookup_widget(objet,"spinbutton17") ;
spinbutton18=lookup_widget(objet,"spinbutton18") ;
spinbutton19=lookup_widget(objet,"spinbutton19") ;
spinbutton20=lookup_widget(objet,"spinbutton20") ;
spinbutton21=lookup_widget(objet,"spinbutton21") ;
spinbutton22=lookup_widget(objet,"spinbutton22") ;
int jf,mf,af,jt,mt,at;
jf=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton17));
mf=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton18));
af=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton19));
jt=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton20));
mt=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton21));
at=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton22));
sprintf (o.from,"%d/%d/%d",jf,mf,af);
sprintf (o.to,"%d/%d/%d",jt,mt,at);
strcpy(o.nomOffre,gtk_entry_get_text(GTK_ENTRY(nomOffreAjout2)));
strcpy(o.adresse,gtk_entry_get_text(GTK_ENTRY(AdresseAjout2)));
strcpy(o.prix,gtk_entry_get_text(GTK_ENTRY(Prix2)));
strcpy(o.nombre_chambre,gtk_entry_get_text(GTK_ENTRY(nombreChambre1)));
strcpy(o.nombre_etoile,"NULL");
o.type=2;
int nombreligne=1;

f=fopen("offreLocal.txt","r");
  if (f!=NULL)
{
  
 while(fscanf(f,"%d %s %s %s %s %s %s %s %d %s\n ",o2.id,o2.nomOffre,o2.adresse,o2.prix,o2.from,o2.to,o2.nombre_etoile,o2.nombre_chambre,&o2.type,o2.agent)!=EOF){
	nombreligne++;	
}
  fclose(f);
}
User u;
f=fopen("userConnected.txt","r");
  if (f!=NULL)
{
  
 while(fscanf(f,"%s %s %s %s %s %s %s %d",u.pseudonyme,u.nom,u.prenom,u.password,u.email,u.adresse,u.telephone,&u.role)!=EOF){	
}
  fclose(f);
}
sprintf (o.id,"%d",nombreligne);
strcpy(o.agent,u.pseudonyme);
f=fopen("offreLocal.txt","a+");
  if (f!=NULL)
{
  fprintf(f,"%s %s %s %s %s %s %s %s %d %s\n",o.id,o.nomOffre,o.adresse,o.prix,o.from,o.to,o.nombre_etoile,o.nombre_chambre,o.type,o.agent);
  g_print("%s %s %s %s %s %s %s %s %d %s\n",o.id,o.nomOffre,o.adresse,o.prix,o.from,o.to,o.nombre_etoile,o.nombre_chambre,o.type,o.agent);
  fclose(f);
}
}

void affHRental (GtkListItem *liste)
{
  GtkCellRenderer *renderer;
  GtkTreeViewColumn *column;
  GtkTreeIter iter;
  GtkListStore *store;
char id[20];
char nomOffre[20];
char adresse[20];
char prix[20];
char from[20];
char to[20];
int type;
char nombre_etoile[20];
char nombre_chambre[20];
char agent[20];
  store=NULL;
  
           FILE*f;
     
     store=gtk_tree_view_get_model(liste);
           if(store==NULL)
{
	 renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("Identifiant",renderer,"text",ID, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
          renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("Nom",renderer,"text",NOM, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
 	  renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("Adresse",renderer,"text",ADRESSE, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
          renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("Prix",renderer,"text",PRIX, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
          renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("Date debut",renderer,"text",FROM, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
           renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("Date fin",renderer,"text",TO, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes(" nombre de chambre",renderer,"text",NOMBRE_CHAMBRE, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
      store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
      f= fopen("offreLocal.txt","r");
      if(f==NULL)
        {
                return;
        }
     else 
       {
	 User u;
	  f=fopen("userConnected.txt","r");
 	 if (f!=NULL)
	{
  
 	while(fscanf(f,"%s %s %s %s %s %s %s %d",u.pseudonyme,u.nom,u.prenom,u.password,u.email,u.adresse,u.telephone,&u.role)!=EOF){	
	}
  	fclose(f);
	}
          f= fopen("offreLocal.txt","a+");
          while(fscanf(f,"%s %s %s %s %s %s %s %s %d %s\n",id,nomOffre,adresse,prix,from,to,nombre_etoile,nombre_chambre,&type,agent)!=EOF)
            {
		if(strcmp(u.pseudonyme,agent)==0 && type==2){
     gtk_list_store_append (store, &iter);
     gtk_list_store_set (store, &iter,ID,id, NOM,nomOffre, ADRESSE, adresse, PRIX, prix, FROM, from, TO, to, NOMBRE_CHAMBRE,nombre_chambre,-1); 
            }}
              fclose(f);
       gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
       g_object_unref (store);
       }
}
}



void suppHRental(char id[20])
{	Offre o;
	FILE *f=NULL;
	FILE *ftemp;
	f=fopen("offreLocal.txt","r");    
	ftemp=fopen("ftemp.txt","w");
	fclose(ftemp);
	ftemp=fopen("ftemp.txt","a+");
	if (f!=NULL)
	 while(fscanf(f,"%s %s %s %s %s %s %s %s %d %s\n",o.id,o.nomOffre,o.adresse,o.prix,o.from,o.to,o.nombre_etoile,o.nombre_chambre,&o.type,o.agent)!=EOF)
    	{
        	if(strcmp(o.id,id)!=0)
        		{
            			fprintf(ftemp,"%s %s %s %s %s %s %s %s %d %s\n",o.id,o.nomOffre,o.adresse,o.prix,o.from,o.to,o.nombre_etoile,o.nombre_chambre,o.type,o.agent);
        		}
        
        
    	}

    
    	fclose(f);
    	fclose(ftemp);
    	remove("/home/houssem123/Projects/houssem_final!!/src/offreLocal.txt");
    	rename("/home/houssem123/Projects/houssem_final!!/src/ftemp.txt","/home/houssem123/Projects/houssem_final!!/src/offreLocal.txt");
 }

/************************************************************************************************************************************/
void ajoutGHouse(GtkWidget       *objet){
Offre o;
Offre o2;
FILE *f;
g_print("ahla");
GtkWidget *nomOffreAjout3,*AdresseAjout3,*Prix3,*nombreChambre2,*spinbutton24,*spinbutton23,*spinbutton25,*spinbutton26,*spinbutton31,*spinbutton32;
nomOffreAjout3=lookup_widget(objet,"nomOffreAjout3") ;
AdresseAjout3=lookup_widget(objet,"AdresseAjout3");
Prix3=lookup_widget(objet,"Prix3") ;
nombreChambre2=lookup_widget(objet,"nombreChambre2") ;
spinbutton23=lookup_widget(objet,"spinbutton23") ;
spinbutton24=lookup_widget(objet,"spinbutton24") ;
spinbutton25=lookup_widget(objet,"spinbutton25") ;
spinbutton26=lookup_widget(objet,"spinbutton26") ;
spinbutton31=lookup_widget(objet,"spinbutton31") ;
spinbutton32=lookup_widget(objet,"spinbutton32") ;
int jf,mf,af,jt,mt,at;
jf=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton24));
mf=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton23));
af=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton25));
jt=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton26));
mt=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton31));
at=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton32));
sprintf (o.from,"%d/%d/%d",jf,mf,af);
sprintf (o.to,"%d/%d/%d",jt,mt,at);
strcpy(o.nomOffre,gtk_entry_get_text(GTK_ENTRY(nomOffreAjout3)));
strcpy(o.adresse,gtk_entry_get_text(GTK_ENTRY(AdresseAjout3)));
strcpy(o.prix,gtk_entry_get_text(GTK_ENTRY(Prix3)));
strcpy(o.nombre_chambre,gtk_entry_get_text(GTK_ENTRY(nombreChambre2)));
strcpy(o.nombre_etoile,"NULL");
o.type=3;
int nombreligne=1;

f=fopen("offreLocal.txt","r");
  if (f!=NULL)
{
  
 while(fscanf(f,"%d %s %s %s %s %s %s %s %d %s\n ",o2.id,o2.nomOffre,o2.adresse,o2.prix,o2.from,o2.to,o2.nombre_etoile,o2.nombre_chambre,&o2.type,o2.agent)!=EOF){
	nombreligne++;	
}
  fclose(f);
}
User u;
f=fopen("userConnected.txt","r");
  if (f!=NULL)
{
  
 while(fscanf(f,"%s %s %s %s %s %s %s %d",u.pseudonyme,u.nom,u.prenom,u.password,u.email,u.adresse,u.telephone,&u.role)!=EOF){	
}
  fclose(f);
}
sprintf (o.id,"%d",nombreligne);
strcpy(o.agent,u.pseudonyme);
f=fopen("offreLocal.txt","a+");
  if (f!=NULL)
{
  fprintf(f,"%s %s %s %s %s %s %s %s %d %s\n",o.id,o.nomOffre,o.adresse,o.prix,o.from,o.to,o.nombre_etoile,o.nombre_chambre,o.type,o.agent);
  g_print("%s %s %s %s %s %s %s %s %d %s\n",o.id,o.nomOffre,o.adresse,o.prix,o.from,o.to,o.nombre_etoile,o.nombre_chambre,o.type,o.agent);
  fclose(f);
}
}

void affGHouse (GtkListItem *liste)
{
  GtkCellRenderer *renderer;
  GtkTreeViewColumn *column;
  GtkTreeIter iter;
  GtkListStore *store;
char id[20];
char nomOffre[20];
char adresse[20];
char prix[20];
char from[20];
char to[20];
int type;
char nombre_etoile[20];
char nombre_chambre[20];
char agent[20];
  store=NULL;
  
           FILE*f;
     
     store=gtk_tree_view_get_model(liste);
           if(store==NULL)
{
	 renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("Identifiant",renderer,"text",ID, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
          renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("Nom",renderer,"text",NOM, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
 	  renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("Adresse",renderer,"text",ADRESSE, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
          renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("Prix",renderer,"text",PRIX, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
          renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("Date debut",renderer,"text",FROM, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
           renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("Date fin",renderer,"text",TO, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes(" nombre de chambre",renderer,"text",NOMBRE_CHAMBRE, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
      store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
      f= fopen("offreLocal.txt","r");
      if(f==NULL)
        {
                return;
        }
     else 
       {
	 User u;
	  f=fopen("userConnected.txt","r");
 	 if (f!=NULL)
	{
  
 	while(fscanf(f,"%s %s %s %s %s %s %s %d",u.pseudonyme,u.nom,u.prenom,u.password,u.email,u.adresse,u.telephone,&u.role)!=EOF){	
	}
  	fclose(f);
	}
          f= fopen("offreLocal.txt","a+");
          while(fscanf(f,"%s %s %s %s %s %s %s %s %d %s\n",id,nomOffre,adresse,prix,from,to,nombre_etoile,nombre_chambre,&type,agent)!=EOF)
            {
		if(strcmp(u.pseudonyme,agent)==0 && type==3){
     gtk_list_store_append (store, &iter);
     gtk_list_store_set (store, &iter,ID,id, NOM,nomOffre, ADRESSE, adresse, PRIX, prix, FROM, from, TO, to, NOMBRE_CHAMBRE,nombre_chambre,-1); 
            }}
              fclose(f);
       gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
       g_object_unref (store);
       }
}
}



void suppGHouse(char id[20])
{	Offre o;
	FILE *f=NULL;
	FILE *ftemp;
	f=fopen("offreLocal.txt","r");    
	ftemp=fopen("ftemp.txt","w");
	fclose(ftemp);
	ftemp=fopen("ftemp.txt","a+");
	if (f!=NULL)
	 while(fscanf(f,"%s %s %s %s %s %s %s %s %d %s\n",o.id,o.nomOffre,o.adresse,o.prix,o.from,o.to,o.nombre_etoile,o.nombre_chambre,&o.type,o.agent)!=EOF)
    	{
        	if(strcmp(o.id,id)!=0)
        		{
            			fprintf(ftemp,"%s %s %s %s %s %s %s %s %d %s\n",o.id,o.nomOffre,o.adresse,o.prix,o.from,o.to,o.nombre_etoile,o.nombre_chambre,o.type,o.agent);
        		}
        
        
    	}

    
    	fclose(f);
    	fclose(ftemp);
    	remove("/home/houssem123/Projects/houssem_final!!/src/offreLocal.txt");
    	rename("/home/houssem123/Projects/houssem_final!!/src/ftemp.txt","/home/houssem123/Projects/houssem_final!!/src/offreLocal.txt");
 }
void affHotelClient (GtkListItem *liste)
{
  GtkCellRenderer *renderer;
  GtkTreeViewColumn *column;
  GtkTreeIter iter;
  GtkListStore *store;
char id[20];
char nomOffre[20];
char adresse[20];
char prix[20];
char from[20];
char to[20];
int type;
char nombre_etoile[20];
char nombre_chambre[20];
char agent[20];
  store=NULL;
  
           FILE*f;
     
     store=gtk_tree_view_get_model(liste);
           if(store==NULL)
{
	 renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("Identifiant",renderer,"text",ID, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
          renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("Nom",renderer,"text",NOM, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
 	  renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("Adresse",renderer,"text",ADRESSE, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
          renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("Prix",renderer,"text",PRIX, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
          renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("Date debut",renderer,"text",FROM, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
           renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("Date fin",renderer,"text",TO, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes(" nombre d'etoile",renderer,"text",NOMBRE_ETOILE, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
      store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING);
      f= fopen("offreLocal.txt","r");
      if(f==NULL)
        {
                return;
        }
     else 
       {
	 User u;
	  f=fopen("userConnected.txt","r");
 	 if (f!=NULL)
	{
  
 	while(fscanf(f,"%s %s %s %s %s %s %s %d",u.pseudonyme,u.nom,u.prenom,u.password,u.email,u.adresse,u.telephone,&u.role)!=EOF){	
	}
  	fclose(f);
	}
          f= fopen("offreLocal.txt","a+");
          while(fscanf(f,"%s %s %s %s %s %s %s %s %d %s\n",id,nomOffre,adresse,prix,from,to,nombre_etoile,nombre_chambre,&type,agent)!=EOF)
            {
		if(type==0){
     gtk_list_store_append (store, &iter);
     gtk_list_store_set (store, &iter,ID,id, NOM,nomOffre, ADRESSE, adresse, PRIX, prix, FROM, from, TO, to, NOMBRE_ETOILE,nombre_etoile,-1); 
            }}
              fclose(f);
       gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
       g_object_unref (store);
       }
}
}
void affMotelClient (GtkListItem *liste)
{
  GtkCellRenderer *renderer;
  GtkTreeViewColumn *column;
  GtkTreeIter iter;
  GtkListStore *store;
char id[20];
char nomOffre[20];
char adresse[20];
char prix[20];
char from[20];
char to[20];
int type;
char nombre_etoile[20];
char nombre_chambre[20];
char agent[20];
  store=NULL;
  
           FILE*f;
     
     store=gtk_tree_view_get_model(liste);
           if(store==NULL)
{
	 renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("Identifiant",renderer,"text",ID, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
          renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("Nom",renderer,"text",NOM, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
 	  renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("Adresse",renderer,"text",ADRESSE, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
          renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("Prix",renderer,"text",PRIX, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
          renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("Date debut",renderer,"text",FROM, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
           renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("Date fin",renderer,"text",TO, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes(" nombre de chambre",renderer,"text",NOMBRE_CHAMBRE, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
      store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
      f= fopen("offreLocal.txt","r");
      if(f==NULL)
        {
                return;
        }
     else 
       {
	 User u;
	  f=fopen("userConnected.txt","r");
 	 if (f!=NULL)
	{
  
 	while(fscanf(f,"%s %s %s %s %s %s %s %d",u.pseudonyme,u.nom,u.prenom,u.password,u.email,u.adresse,u.telephone,&u.role)!=EOF){	
	}
  	fclose(f);
	}
          f= fopen("offreLocal.txt","a+");
          while(fscanf(f,"%s %s %s %s %s %s %s %s %d %s\n",id,nomOffre,adresse,prix,from,to,nombre_etoile,nombre_chambre,&type,agent)!=EOF)
            {
	if(type==1){
     gtk_list_store_append (store, &iter);
     gtk_list_store_set (store, &iter,ID,id, NOM,nomOffre, ADRESSE, adresse, PRIX, prix, FROM, from, TO, to, NOMBRE_CHAMBRE,nombre_chambre,-1); 
            }}
              fclose(f);
       gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
       g_object_unref (store);
       }
}
}
void affHRentalClient (GtkListItem *liste)
{
  GtkCellRenderer *renderer;
  GtkTreeViewColumn *column;
  GtkTreeIter iter;
  GtkListStore *store;
char id[20];
char nomOffre[20];
char adresse[20];
char prix[20];
char from[20];
char to[20];
int type;
char nombre_etoile[20];
char nombre_chambre[20];
char agent[20];
  store=NULL;
  
           FILE*f;
     
     store=gtk_tree_view_get_model(liste);
           if(store==NULL)
{
	 renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("Identifiant",renderer,"text",ID, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
          renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("Nom",renderer,"text",NOM, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
 	  renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("Adresse",renderer,"text",ADRESSE, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
          renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("Prix",renderer,"text",PRIX, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
          renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("Date debut",renderer,"text",FROM, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
           renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("Date fin",renderer,"text",TO, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes(" nombre de chambre",renderer,"text",NOMBRE_CHAMBRE, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
      store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
      f= fopen("offreLocal.txt","r");
      if(f==NULL)
        {
                return;
        }
     else 
       {
	 User u;
	  f=fopen("userConnected.txt","r");
 	 if (f!=NULL)
	{
  
 	while(fscanf(f,"%s %s %s %s %s %s %s %d",u.pseudonyme,u.nom,u.prenom,u.password,u.email,u.adresse,u.telephone,&u.role)!=EOF){	
	}
  	fclose(f);
	}
          f= fopen("offreLocal.txt","a+");
          while(fscanf(f,"%s %s %s %s %s %s %s %s %d %s\n",id,nomOffre,adresse,prix,from,to,nombre_etoile,nombre_chambre,&type,agent)!=EOF)
            {
		if(type==2){
     gtk_list_store_append (store, &iter);
     gtk_list_store_set (store, &iter,ID,id, NOM,nomOffre, ADRESSE, adresse, PRIX, prix, FROM, from, TO, to, NOMBRE_CHAMBRE,nombre_chambre,-1); 
            }}
              fclose(f);
       gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
       g_object_unref (store);
       }
}
}
void affGHouseClient (GtkListItem *liste)
{
  GtkCellRenderer *renderer;
  GtkTreeViewColumn *column;
  GtkTreeIter iter;
  GtkListStore *store;
char id[20];
char nomOffre[20];
char adresse[20];
char prix[20];
char from[20];
char to[20];
int type;
char nombre_etoile[20];
char nombre_chambre[20];
char agent[20];
  store=NULL;
  
           FILE*f;
     
     store=gtk_tree_view_get_model(liste);
           if(store==NULL)
{
	 renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("Identifiant",renderer,"text",ID, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
          renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("Nom",renderer,"text",NOM, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
 	  renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("Adresse",renderer,"text",ADRESSE, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
          renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("Prix",renderer,"text",PRIX, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
          renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("Date debut",renderer,"text",FROM, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
           renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("Date fin",renderer,"text",TO, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes(" nombre de chambre",renderer,"text",NOMBRE_CHAMBRE, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
      store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
      f= fopen("offreLocal.txt","r");
      if(f==NULL)
        {
                return;
        }
     else 
       {
	 User u;
	  f=fopen("userConnected.txt","r");
 	 if (f!=NULL)
	{
  
 	while(fscanf(f,"%s %s %s %s %s %s %s %d",u.pseudonyme,u.nom,u.prenom,u.password,u.email,u.adresse,u.telephone,&u.role)!=EOF){	
	}
  	fclose(f);
	}
          f= fopen("offreLocal.txt","a+");
          while(fscanf(f,"%s %s %s %s %s %s %s %s %d %s\n",id,nomOffre,adresse,prix,from,to,nombre_etoile,nombre_chambre,&type,agent)!=EOF)
            {
	if(type==3){
     gtk_list_store_append (store, &iter);
     gtk_list_store_set (store, &iter,ID,id, NOM,nomOffre, ADRESSE, adresse, PRIX, prix, FROM, from, TO, to, NOMBRE_CHAMBRE,nombre_chambre,-1); 
            }}
              fclose(f);
       gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
       g_object_unref (store);
       }
}
}




