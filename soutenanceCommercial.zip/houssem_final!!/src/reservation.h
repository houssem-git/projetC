#include <gtk/gtk.h>
#include "interface.h"
#include "support.h"
#include "Offre.h"

struct Reservation {
char pseudonyme[20];
char id[20];
char DateDebut[20];
char DateFin[20];
};
typedef struct Reservation Reservation;
void ajouterReservationHotel(GtkWidget       *objet,char id[20]);
void ajouterReservationMotel(GtkWidget       *objet,char id[20]);
void ajouterReservationHouse(GtkWidget       *objet,char id[20]);
void ajouterReservationGHouse(GtkWidget       *objet,char id[20]);
void affReserv (GtkListItem *liste);
void suppreserv(char pseudonyme[20],char id[20]);
