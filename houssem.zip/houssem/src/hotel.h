#include <gtk/gtk.h>
#include "interface.h"
#include "support.h"
 struct Hotel
{
char noun[20];
char location[20];
char starsNumber[20];
char from[20];
char to[20];
};
typedef struct Hotel Hotel;

void ajouterhotel (GtkWidget       *objet);
void afficherhotel(GtkListItem *liste);
//sprintf (from,"%d /%d /%d",jf,mf,af)
