#include <gtk/gtk.h>
#include "interface.h"
#include "support.h"
#include "user.h"
 struct Offre
{
char id[20];
char nomOffre[20];
char adresse[20];
char prix[20];
char from[20];
char to[20];
int type;
char nombre_etoile[20];
char nombre_chambre[20];
char agent[20];
};
typedef struct Offre Offre;
void ajoutHotel(GtkWidget       *objet);
void aff (GtkListItem *liste);
void suppressionhotel(int id);


