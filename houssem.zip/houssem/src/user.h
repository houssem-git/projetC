#include <gtk/gtk.h>
#include "interface.h"
#include "support.h"
struct User {
char pseudonyme[20];
char nom[20];
char prenom[20];
char password[20];
char email[20];
char adresse[20];
char telephone[8];
int role;
};
typedef struct User User;
void ajouterAgent(GtkWidget       *objet);
void ajouterClient(GtkWidget       *objet);
User getUser(char Pseudo[20],char passw[20]);



