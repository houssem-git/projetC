#include <gtk/gtk.h>
#include "reservation.h" 
#include <string.h>
#include <stdlib.h>


void ajouterReservationHotel(GtkWidget       *objet,char id[20]){
Reservation r;
FILE *f;
GtkWidget *spinbutton33,*spinbutton34,*spinbutton35,*spinbutton39,*spinbutton40,*spinbutton41;
spinbutton33=lookup_widget(objet,"spinbutton33") ;
spinbutton34=lookup_widget(objet,"spinbutton34") ;
spinbutton35=lookup_widget(objet,"spinbutton35") ;
spinbutton39=lookup_widget(objet,"spinbutton39") ;
spinbutton40=lookup_widget(objet,"spinbutton40") ;
spinbutton41=lookup_widget(objet,"spinbutton41") ;
int jf,mf,af,jt,mt,at;
jf=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton33));
mf=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton34));
af=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton35));
jt=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton39));
mt=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton40));
at=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton41));
sprintf (r.DateDebut,"%d/%d/%d",jf,mf,af);
sprintf (r.DateFin,"%d/%d/%d",jt,mt,at);
User u;
f=fopen("userConnected.txt","r");
  if (f!=NULL)
{
  
 while(fscanf(f,"%s %s %s %s %s %s %s %d",u.pseudonyme,u.nom,u.prenom,u.password,u.email,u.adresse,u.telephone,&u.role)!=EOF){	
}
  fclose(f);
}
strcpy(r.pseudonyme,u.pseudonyme);
strcpy(r.id,id);
f=fopen("Reservation.txt","a+");
  if (f!=NULL)
{
  fprintf(f,"%s %s %s %s\n",r.pseudonyme,r.id,r.DateDebut,r.DateFin);
  g_print("%s %s %s %s\n",r.pseudonyme,r.id,r.DateDebut,r.DateFin);
  fclose(f);
}
}
void ajouterReservationMotel(GtkWidget       *objet,char id[20]){
Reservation r;
FILE *f;
GtkWidget *spinbutton36,*spinbutton37,*spinbutton38,*spinbutton42,*spinbutton43,*spinbutton44;
spinbutton36=lookup_widget(objet,"spinbutton36") ;
spinbutton37=lookup_widget(objet,"spinbutton37") ;
spinbutton38=lookup_widget(objet,"spinbutton38") ;
spinbutton42=lookup_widget(objet,"spinbutton42") ;
spinbutton43=lookup_widget(objet,"spinbutton43") ;
spinbutton44=lookup_widget(objet,"spinbutton44") ;
int jf,mf,af,jt,mt,at;
jf=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton36));
mf=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton37));
af=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton38));
jt=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton42));
mt=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton43));
at=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton44));
sprintf (r.DateDebut,"%d/%d/%d",jf,mf,af);
sprintf (r.DateFin,"%d/%d/%d",jt,mt,at);
User u;
f=fopen("userConnected.txt","r");
  if (f!=NULL)
{
  
 while(fscanf(f,"%s %s %s %s %s %s %s %d",u.pseudonyme,u.nom,u.prenom,u.password,u.email,u.adresse,u.telephone,&u.role)!=EOF){	
}
  fclose(f);
}
strcpy(r.pseudonyme,u.pseudonyme);
strcpy(r.id,id);
f=fopen("Reservation.txt","a+");
  if (f!=NULL)
{
  fprintf(f,"%s %s %s %s\n",r.pseudonyme,r.id,r.DateDebut,r.DateFin);
  g_print("%s %s %s %s\n",r.pseudonyme,r.id,r.DateDebut,r.DateFin);
  fclose(f);
}
}
void ajouterReservationHouse(GtkWidget       *objet,char id[20]){
Reservation r;
FILE *f;
GtkWidget *spinbutton1,*spinbutton2,*spinbutton3,*spinbutton4,*spinbutton5,*spinbutton6;
spinbutton1=lookup_widget(objet,"spinbutton45") ;
spinbutton2=lookup_widget(objet,"spinbutton46") ;
spinbutton3=lookup_widget(objet,"spinbutton47") ;
spinbutton4=lookup_widget(objet,"spinbutton48") ;
spinbutton5=lookup_widget(objet,"spinbutton49") ;
spinbutton6=lookup_widget(objet,"spinbutton50") ;
int jf,mf,af,jt,mt,at;
jf=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton1));
mf=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton2));
af=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton3));
jt=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton4));
mt=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton5));
at=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton6));
sprintf (r.DateDebut,"%d/%d/%d",jf,mf,af);
sprintf (r.DateFin,"%d/%d/%d",jt,mt,at);
User u;
f=fopen("userConnected.txt","r");
  if (f!=NULL)
{
  
 while(fscanf(f,"%s %s %s %s %s %s %s %d",u.pseudonyme,u.nom,u.prenom,u.password,u.email,u.adresse,u.telephone,&u.role)!=EOF){	
}
  fclose(f);
}
strcpy(r.pseudonyme,u.pseudonyme);
strcpy(r.id,id);
f=fopen("Reservation.txt","a+");
  if (f!=NULL)
{
  fprintf(f,"%s %s %s %s\n",r.pseudonyme,r.id,r.DateDebut,r.DateFin);
  g_print("%s %s %s %s\n",r.pseudonyme,r.id,r.DateDebut,r.DateFin);
  fclose(f);
}
}
void ajouterReservationGHouse(GtkWidget       *objet,char id[20]){
Reservation r;
FILE *f;
GtkWidget *spinbutton1,*spinbutton2,*spinbutton3,*spinbutton4,*spinbutton5,*spinbutton6;
spinbutton1=lookup_widget(objet,"spinbutton51") ;
spinbutton2=lookup_widget(objet,"spinbutton52") ;
spinbutton3=lookup_widget(objet,"spinbutton53") ;
spinbutton4=lookup_widget(objet,"spinbutton54") ;
spinbutton5=lookup_widget(objet,"spinbutton55") ;
spinbutton6=lookup_widget(objet,"spinbutton56") ;
int jf,mf,af,jt,mt,at;
jf=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton1));
mf=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton2));
af=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton3));
jt=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton4));
mt=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton5));
at=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton6));
sprintf (r.DateDebut,"%d/%d/%d",jf,mf,af);
sprintf (r.DateFin,"%d/%d/%d",jt,mt,at);
User u;
f=fopen("userConnected.txt","r");
  if (f!=NULL)
{
  
 while(fscanf(f,"%s %s %s %s %s %s %s %d",u.pseudonyme,u.nom,u.prenom,u.password,u.email,u.adresse,u.telephone,&u.role)!=EOF){	
}
  fclose(f);
}
strcpy(r.pseudonyme,u.pseudonyme);
strcpy(r.id,id);
f=fopen("Reservation.txt","a+");
  if (f!=NULL)
{
  fprintf(f,"%s %s %s %s\n",r.pseudonyme,r.id,r.DateDebut,r.DateFin);
  g_print("%s %s %s %s\n",r.pseudonyme,r.id,r.DateDebut,r.DateFin);
  fclose(f);
}
}
enum{
PSEUDONYME,
ID,
DATEDEBUT,
DATEFIN,
COLUMNS
};
void affReserv(GtkListItem *liste)
{
  GtkCellRenderer *renderer;
  GtkTreeViewColumn *column;
  GtkTreeIter iter;
  GtkListStore *store;
char pseudonyme[20];
char idFkey[20];
char nomOffre[20];
char prix[20];
char DateDebut[20];
char DateFin[20];
  store=NULL;
  
           FILE*f;
     
     store=gtk_tree_view_get_model(liste);
           if(store==NULL)
{
 		renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("Mon Pseudonyme",renderer,"text",PSEUDONYME, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);	 
	 renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("id de l'offre",renderer,"text",ID, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);       
	 renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("debut de la reservation",renderer,"text",DATEDEBUT, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
 	  renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("fin de la reservation",renderer,"text",DATEFIN, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
         
      store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING);
      f= fopen("Reservation.txt","r");
      if(f==NULL)
        {
                return;
        }
     else 
       {
	 User u;
	  f=fopen("userConnected.txt","r");
 	 if (f!=NULL)
	{
  
 	while(fscanf(f,"%s %s %s %s %s %s %s %d",u.pseudonyme,u.nom,u.prenom,u.password,u.email,u.adresse,u.telephone,&u.role)!=EOF){	
	}
  	fclose(f);
	}
          f= fopen("Reservation.txt","a+");
          while(fscanf(f,"%s %s %s %s\n",pseudonyme,idFkey,DateDebut,DateFin)!=EOF)
            {
		
		if((strcmp(u.pseudonyme,pseudonyme)==0)){
     gtk_list_store_append (store, &iter);
     gtk_list_store_set (store, &iter,PSEUDONYME,pseudonyme,ID,idFkey, DATEDEBUT,DateDebut, DATEFIN, DateFin,-1); 
            }}
              fclose(f);
       gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
       g_object_unref (store);
       }
}
}
void suppreserv(char pseudonyme[20],char id[20])
{	Reservation r;
	FILE *f=NULL;
	FILE *ftemp;
	f=fopen("Reservation.txt","r");    
	ftemp=fopen("ftemp.txt","w");
	fclose(ftemp);
	ftemp=fopen("ftemp.txt","a+");
	if (f!=NULL)
	 while(fscanf(f,"%s %s %s %s\n",r.pseudonyme,r.id,r.DateDebut,r.DateFin)!=EOF)
    	{
        	if((strcmp(r.id,id)!=0)&&(strcmp(r.pseudonyme,pseudonyme)!=0))
        		{
            			fprintf(ftemp,"%s %s %s %s\n",r.pseudonyme,r.id,r.DateDebut,r.DateFin);
        		}
        
        
    	}

    
    	fclose(f);
    	fclose(ftemp);
    	remove("/home/houssem123/Projects/Sofien2/src/Reservation.txt");
    	rename("/home/houssem123/Projects/Sofien2/src/ftemp.txt","/home/houssem123/Projects/Sofien2/src/Reservation.txt");
 }
