#include <stdio.h>
#include <string.h>
#include "plane.h"
#include <gtk/gtk.h>
#include <stdlib.h>
 enum
{
	 IDOFFRE; 
	 DROPIN,
	 DROPOFF,
	 FROM,
	 TO,
	 NAMETRANSPORT,
	 NBPLACESPIN,
	 PRICETICKET,
	 CLASSCOMBO,
	 COLUMNS
 };
 //ajoutplane
void ajouter_plane(GtkWidget       *objet)
{	 offre p;
	 FILE *f;
	 int jf,mf,af,jt,mt,at,nps;
	 GtkWidget *input1 ,*input2,*input3,*input4,*input5,*input6,*input7,*input8,*input9,*input10,*input11,*input12;
  	 GtkWidget *comboboxentryclass;
	 
	//input1=lookup_widget(objet,"idoffre") ;
	//strcpy(p.idoffre,gtk_entry_get_text(GTK_ENTRY(input1)));	
	input2=lookup_widget(objet,"dropin") ;
 	input3=lookup_widget(objet,"dropoff") ;
 	strcpy(p.dropinplane,gtk_entry_get_text(GTK_ENTRY(input2)));
 	strcpy(p.dropoffplane,gtk_entry_get_text(GTK_ENTRY(input3)));	
//fromto
 	input4= lookup_widget(objet,"dayplanefrom") ;
  	 input5= lookup_widget(objet,"mothplanetofrom") ;
  	input6= lookup_widget(objet,"yearplanefrom") ;
  	input7= lookup_widget(objet,"dayplaneto") ;
  	input8= lookup_widget(objet,"monthplaneto") ;
  	input9= lookup_widget(objet,"yearplaneto") ;
    
  jf=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input4));
  mf=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input5));
  af=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input6));
  jt=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input7));
  mt=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input8));
  at=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input9));

	sprintf (p.from,"%d/%d/%d",jf,mf,af);
        sprintf (p.to,"%d/%d/%d",jt,mt,at);
 //

	input10=lookup_widget(objet,"nametransport") ;
	strcpy(p.nametransport,gtk_entry_get_text(GTK_ENTRY(input10)));

	input11=lookup_widget(objet,"nbplacespin") ;
	nps=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input11));

 	input12=lookup_widget(objet,"priceticket") ;
 	strcpy(p.priceticket,gtk_entry_get_text(GTK_ENTRY(input12)));
//combobox
	comboboxentryclass=lookup_widget(objet,"comboboxentryclass") ;
  	if(strcmp("first_class",gtk_combo_box_get_active_text(GTK_COMBO(comboboxentryclass)))==0)
  	strcpy(p.classcombo,"first_class");
  	else
  	strcpy(p.classcombo,"normal_class");
//
	
	
 
	 f=fopen("plane.txt","a+");
	 if (f!=NULL)
	 {
		 fprintf(f,"%s %s %s %s %s %s %s %s %s\n",p.idoffre,p.dropin,p.dropoff,p.from,p.to,p.nametransport,p.nbplacespin,p.priceticket,p.classcombo);
		 fclose(f);
	 }
 }

 
 //afficherplane
 void afficher_plane(GtkListItem *liste)
 {	 offre p;
	 GtkCellRenderer *renderer ;+++
	 GtkTreeViewColumn *column;
	 GtkTreeIter iter;
	 GtkListStore *store;
	 int jf,mf,af,jt,mt,at;
	 GtkWidget *input1 ,*input2,*input3,*input4,*input5,*input6;
	 char idoffre[20];
	 char dropin[20];
     	 char dropoff[20];
     	 char from[20];
     	 char to[20];
     	 char nametransport[20];
	 char nbplacespin[20];
	 char priceticket[20];
	 char classcombo[20];
	 char type[20];
	 store=NULL;
	 FILE *f;
	 store=gtk_tree_view_get_model(liste);
	 if ((store==NULL)&&(strcmp(type,"plane")==0)
	 {
		 renderer= gtk_cell_renderer_text_new();
		 column=gtk_tree_view_column_new_with_attributes("idoffre", renderer,"text", IDOFFRE,NULL);
		 gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

		 renderer= gtk_cell_renderer_text_new();
		 column=gtk_tree_view_column_new_with_attributes("dropin", renderer,"text", DROPIN,NULL);
		 gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

		 renderer=gtk_cell_renderer_text_new();
		 column= gtk_tree_view_column_new_with_attributes("dropoff", renderer,"text", DROPOFF,NULL);
		 gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

		 renderer=gtk_cell_renderer_text_new();
		 column= gtk_tree_view_column_new_with_attributes("from", renderer,"text", FROM,NULL);
		 gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

		 renderer=gtk_cell_renderer_text_new();
		 column= gtk_tree_view_column_new_with_attributes("to", renderer,"text", TO,NULL);
		 gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

		 renderer=gtk_cell_renderer_text_new();
		 column= gtk_tree_view_column_new_with_attributes("nametransport", renderer,"text", NAMETRANSPORT,NULL);
		 gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

		 renderer=gtk_cell_renderer_text_new();
                 column= gtk_tree_view_column_new_with_attributes("nbplacespin", renderer,"text", NBPLACESPIN,NULL);
                 gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	         renderer=gtk_cell_renderer_text_new();    
                 column= gtk_tree_view_column_new_with_attributes("priceticket", renderer,"text", PRICETICKET,NULL);
                 gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	         renderer=gtk_cell_renderer_text_new();    
                 column= gtk_tree_view_column_new_with_attributes("classcombo", renderer,"text", CLASSCOMBO,NULL);
                 gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
	         

		 store =gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
		 f=fopen("plane.txt", "r"); //plane.bin
		 if (f==NULL)
		 {
			 return;
		 }
		 else 
		 { f=fopen("plane.txt","a+");//ab
				while (
fscanf(f,"%s %s %s %s %s %s %s %s %s\n",idoffre,dropin,dropoff,from,to,nametransport,nbplacespin,priceticket,classcombo)!=EOF) 
							//fread(nomstructure)
				{
					gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,IDOFFRE,idoffre,DROPIN,dropin,DROPOFF,dropoff,FROM,from,TO,to,NAMETRANSPORT,nametransport,NBPLACESPIN,nbplacespin,PRICETICKET,priceticket,CLASSCOMBO,classcombo,-1);
					
				}
				fclose(f);
				gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
				gtk_object_unref(store);
		 }
	 }
}



//suppressionplane
void supprimervol(char idoffresupp[])
{	offre p;
	FILE *f=NULL;
	FILE *ftemp;
	f=fopen("plane.txt","r");    
	ftemp=fopen("ftemp.txt","w");
	fclose(ftemp);
	ftemp=fopen("ftemp.txt","a+");
	if (f!=NULL)
while(fscanf(f,"%s %s %s %s %s %s %s %s %s\n",idoffre,dropin,dropoff,from,to,nametransport,nbplacespin,priceticket,classcombo)!=EOF)
	
    	{
 	g_print("\nNom jey %s     Nom mawjoud %s",idvolsupp,p.idvol);
        	if(strcmp(p.idoffre==idoffresupp)!=0)
        		{
fprintf(ftemp,"%s %s %s %s %s %s %s %s %s\n",p.idoffre,p.dropinplane,p.dropoffplane,p.from,p.to,p.nameplane,p.nbplacespin,p.priceticket,p.classcombo);           			

        		}
        
        
    	}

    
    	fclose(f);
    	fclose(ftemp);
    	remove("/home/Projects/project5/src/plane.txt");
    	rename("/home/Projects/project5/src/ftemp.txt","/home/Projects/project5/src/plane.txt");
    }
//***********************************************************
void supprimerplane(char idvol[20])
{plane p; 
FILE* f=NULL;
FILE* Ftempsupp;
f=fopen("plane.txt","r");
Ftempsupp=fopen("planetemp.txt","w");
fclose(Ftemp);
Ftempsupp=fopen("planetemp.txt","a+");
if (f!=NULL)
while(fscanf(f,"%s %s %s %s %s %s %s %s %s\n",idvol,dropinplane,dropoffplane,from,to,nameplane,nbplacespin,priceticket,classcombo)!=EOF)
{
  fscanf(f,"%s %s %s %s %s %s %s %s %s\n",p.idvol,p.dropinplane,p.dropoffplane,p.from,p.to,p.nameplane,p.nbplacespin,p.priceticket,p.classcombo)  
 //fscanf(f,"%s %s %s %s %s\n",a.id,a.password,a.name,a.adress,a.phone);

     if(strcmp(p.idvol,idvol)!=0)
         {
		fprintf(Ftempsupp,"%s %s %s %s %s %s %s %s %s\n",p.idvol,p.dropinplane,p.dropoffplane,p.from,p.to,p.nameplane,p.nbplacespin,p.priceticket,p.classcombo);
   	 }
}

fclose(f);
fclose(Ftempsupp);
remove("plane.txt");
rename("planetemp.txt","agent.txt");
}
/******************************modifier********************/
void modifierplane(char idvol)
{
  FILE*f;
  FILE*Ftemp;
  plane p; a;

  f=fopen("plane.txt","r");
  Ftemp=fopen("plane.tmp","w");
  if(f!=NULL)
  {
    while(fscanf(f,"%s %s %s %s %s \n",a.id,a.password,a.name,a.adress,a.phone)!=EOF)
    {
      if(a.id != idm)
      {	fprintf(Ftemp,"%s %s %s %s %s \n",a.id,a.password,a.name,a.adress,a.phone);}
    else{
            fprintf(Ftemp,"%s %s %s %s %s \n",a.id,a.password,a.name,a.adress,a.phone);}
    }
  fclose(f);
  fclose(Ftemp);

  remove("agent.txt");
  rename("agent.tmp","agent.txt");
}
}

/*
void supprimer_plane(plane p)
{	 
	 FILE *f;
	 f=fopen("plane.txt","w+");
	 if (f!=NULL) 
	 {
		 
fprintf(f,"%s %s %s %s %s %s %d %d %d %d %d %d %d\n",p.dropinplane,p.dropoffplane,p.from,p.to,p.nameplane,p.nbplace,p.nbplacespin);
		 fclose(f);
	 }
 }
*/
