#include <gtk/gtk.h>


void
on_afficherplane_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ajoutplane_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_retour_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttontransportation_clicked        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonplane_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonretourfenetrechoix_clicked    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonadd_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonback_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonreturnfenetreajout_clicked    (GtkWidget      *objet,
                                        gpointer         user_data);



void on_buttondelete_clicked (GtkWidget       *objet,
                                        gpointer         user_data);
