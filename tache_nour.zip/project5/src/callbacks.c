#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "plane.h"


void
on_afficherplane_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetreajoutplane;
GtkWidget *fenetreafficherplane;
GtkWidget *treeview1;

fenetreajoutplane=lookup_widget(objet,"fenetreajoutplane");
gtk_widget_destroy(fenetreajoutplane);
fenetreafficherplane=lookup_widget(objet,"fenetreafficherplane");
fenetreafficherplane=create_fenetreafficherplane();

gtk_widget_show(fenetreafficherplane);

treeview1=lookup_widget(fenetreafficherplane,"treeview1");
afficher_plane(treeview1);

}
/* 
GtkWidget *hotelOffers ;
GtkWidget *listehotel ;
GtkWidget *treeview1;
hotelOffers=lookup_widget(objet,"hotelOffers");
  gtk_widget_destroy(hotelOffers);
  //listehotel=lookup_widget(objet,"listehotel");
  listehotel=create_listehotel();
   gtk_widget_show(listehotel);
treeview1=lookup_widget(listehotel,"treeview1");
*/

void
on_ajoutplane_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *sortie;
offre p;
int nboffre=1;
ajouter_plane(objet);
f=fopen("offretransport.txt","r+");
if(f!=NULL) {
	
	 while( fscanf(f,"%s %s %s %s %s %s %s %s %s %s\n",idoffre,dropin,dropoff,from,to,nametransport,nbplacespin,priceticket,classcombo,type)!=EOF)
{ 	
nboffre++;
}
idoffre=nboffre; 
	     }
f=fopen("offre.txt","a+");
if(f!=NULL) { ;
fprintf(f,"%s %s %s %s %s %s %s %s %s %s\n",p.idoffre,p.dropin,p.dropoff,p.from,p.to,p.nametransport,p.nbplacespin,p.priceticket,p.classcombo,p.type) 
}
fclose(f);


		


sortie=lookup_widget(objet,"label7");
gtk_label_set_text(GTK_LABEL(sortie),"ajout effectué avec succée");


}


void
on_retour_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetreajoutplane, *fenetreafficherplane;
fenetreafficherplane=lookup_widget(objet,"fenetreafficherplane");
gtk_widget_destroy(fenetreafficherplane);
fenetreajoutplane=create_fenetreajoutplane();
gtk_widget_show(fenetreajoutplane);
}


void
on_buttontransportation_clicked        (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetrechoixtransport, *homeagent;
homeagent=lookup_widget(objet,"homeagent");

fenetrechoixtransport=create_fenetrechoixtransport();
gtk_widget_show(fenetrechoixtransport);
gtk_widget_hide(homeagent);

}


void
on_buttonplane_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetrechoixtransport, *fenetregestionplane;
fenetrechoixtransport=lookup_widget(objet,"fenetrechoixtransport");

fenetregestionplane=create_fenetregestionplane();
gtk_widget_show(fenetregestionplane);
gtk_widget_hide(fenetrechoixtransport);
}


void
on_buttonretourfenetrechoix_clicked    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetrechoixtransport, *homeagent;
fenetrechoixtransport=lookup_widget(objet,"fenetrechoixtransport");

homeagent=create_homeagent();
gtk_widget_show(homeagent);
gtk_widget_hide(fenetrechoixtransport);

}


void
on_buttonadd_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetregestionplane, *fenetreajoutplane;
fenetregestionplane=lookup_widget(objet,"fenetregestionplane");

fenetreajoutplane=create_fenetreajoutplane();
gtk_widget_show(fenetreajoutplane);
gtk_widget_hide(fenetregestionplane);
}


void
on_buttonback_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{

GtkWidget *fenetregestionplane, *fenetrechoixtransport;
fenetregestionplane=lookup_widget(objet,"fenetregestionplane");

fenetrechoixtransport=create_fenetrechoixtransport();
gtk_widget_show(fenetrechoixtransport);
gtk_widget_hide(fenetregestionplane);


}


void
on_buttonreturnfenetreajout_clicked    (GtkWidget       *objet,
                                        gpointer         user_data)
{

}
void on_buttondelete_clicked (GtkWidget       *objet,
                                        gpointer         user_data)
{

}
