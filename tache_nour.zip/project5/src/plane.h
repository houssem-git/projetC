#include <gtk/gtk.h>
#include "interface.h"
#include "support.h"

/*typedef struct 
{
char idvol[20];
char dropinplane[20];
char dropoffplane[20];
char from[20];
char to[20];
char nameplane[20];
char nbplacespin[20];
char priceticket[20];
char classcombo[20];
}plane; */
typedef struct 
{
char idoffre[20];
char dropin[20];
char dropoff[20];
char from[20];
char to[20];
char nametransport[20];
char nbplacespin[20];
char priceticket[20];
char classcombo[20];
char type[20];
}offre;


void ajouter_plane(GtkWidget       *objet);
void afficher_plane(GtkListItem *liste);
void supprimerplane(char idvol[20]) ;
