#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"


void
on_addHotelsOfferLIST_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_consultHotelsOfferLIST_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_save_clicked                        (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_cancel_clicked                      (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_sendHRO_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_motelProv_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_consultProv_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_hotelprov_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_guesthouseProv_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_houseRental_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_transportation_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_Housing_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window;
GtkWidget *providerAccount;
providerAccount=lookup_widget(button,"providerAccount");
window=create_choiceProvH();
gtk_widget_hide(providerAccount);
gtk_widget_show_all(window);

}


void
on_choiceH2_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_choiceH1_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window;
GtkWidget *choiceProvH;
choiceProvH=lookup_widget(button,"choiceProvH");
window=create_hotelsOffer();
gtk_widget_hide(choiceProvH);
gtk_widget_show_all(window);


}


void
on_modifyHotelsOfferLIST_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_deleteHotelsOfferLIST_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{

}

