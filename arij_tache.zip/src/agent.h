#include <gtk/gtk.h>
typedef struct agent
{
char id[20];
char password[20];  
char name[30];
char adress[30];
char phone[10];
}Agent;
void ajouter_agent (Agent a);
void afficher_agent (GtkListItem * liste);
void supprimer_agent(char ids[20]) ;

