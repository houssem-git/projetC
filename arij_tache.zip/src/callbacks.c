#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "agent.h"

Agent agent_selectionner ; 
void
on_button_show_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_ajouter;
GtkWidget *fenetre_afficher;
GtkWidget *treeview1;
  fenetre_ajouter=lookup_widget(objet,"fenetre_ajouter");
  gtk_widget_destroy(fenetre_ajouter);
  fenetre_afficher=lookup_widget(objet,"fenetre_afficher");
  fenetre_afficher=create_fenetre_afficher();
   gtk_widget_show(fenetre_afficher);
treeview1=lookup_widget(fenetre_afficher,"treeview1");
afficher_agent(treeview1);

  
}


void
on_button_home_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{GtkWidget *fenetre_ajouter, *fenetre_admin;
fenetre_ajouter=lookup_widget(objet,"fenetre_ajouter");
gtk_widget_destroy(fenetre_ajouter);
fenetre_admin=create_fenetre_admin();
gtk_widget_show(fenetre_admin);

}


void
on_button_add_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
Agent a;
  GtkWidget *input1, *input2, *input3, *input4, *input5;
  GtkWidget *fenetre_ajouter;
  fenetre_ajouter=lookup_widget(objet,"fenetre_ajouter");
  input1=lookup_widget(objet,"idagent");
  input2=lookup_widget(objet,"passwordagent");
  input3=lookup_widget(objet,"nameagent");
  input4=lookup_widget(objet,"adressagent");
  input5=lookup_widget(objet,"phoneagent");
  strcpy(a.id,gtk_entry_get_text(GTK_ENTRY(input1)));
  strcpy(a.password,gtk_entry_get_text(GTK_ENTRY(input2)));
  strcpy(a.name,gtk_entry_get_text(GTK_ENTRY(input3)));
  strcpy(a.adress,gtk_entry_get_text(GTK_ENTRY(input4)));
  strcpy(a.phone,gtk_entry_get_text(GTK_ENTRY(input5)));
  ajouter_agent(a);
  
}


void
on_button_retour_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{GtkWidget *fenetre_ajouter, *fenetre_afficher;
fenetre_afficher=lookup_widget(objet,"fenetre_afficher");
gtk_widget_destroy(fenetre_afficher);
fenetre_ajouter=create_fenetre_ajouter();
gtk_widget_show(fenetre_ajouter);

}


void
on_manage_agent_account_clicked        (GtkWidget       *objet,
                                        gpointer         user_data)
{GtkWidget *fenetre_admin, *fenetre_ajouter;
fenetre_admin=lookup_widget(objet,"fenetre_admin");
gtk_widget_destroy(fenetre_admin);
fenetre_ajouter=create_fenetre_ajouter();
gtk_widget_show(fenetre_ajouter);

}


void
on_show_client_list_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{

}


void
on_deleteagent_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_supprimer, *fenetre_afficher;
fenetre_afficher=lookup_widget(objet,"fenetre_afficher");
gtk_widget_destroy(fenetre_afficher);
fenetre_supprimer=create_fenetre_supprimer();
gtk_widget_show(fenetre_supprimer);


}

void
on_modifyagent_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{ GtkWidget *fenetre_modifier ;
  GtkWidget *fenetre_afficher ;
  GtkWidget *out;
  

fenetre_modifier=create_fenetre_modifier();
fenetre_afficher=lookup_widget(objet,"fenetre_afficher");
gtk_widget_destroy(fenetre_afficher);
gtk_widget_show(fenetre_modifier);
out=lookup_widget(fenetre_modifier,"entry_id_m");
gtk_entry_set_text (out,agent_selectionner.id);
out=lookup_widget(fenetre_modifier,"entry_password_m");
gtk_entry_set_text (out,agent_selectionner.password);
out=lookup_widget(fenetre_modifier,"entry_name_m");
gtk_entry_set_text (out,agent_selectionner.name);
out=lookup_widget(fenetre_modifier,"entry_adress_m");
gtk_entry_set_text (out,agent_selectionner.adress);
out=lookup_widget(fenetre_modifier,"entry_phone_m");
gtk_entry_set_text (out,agent_selectionner.phone);
}


void
on_delete_id_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{ Agent a;
  char ids[20]; 
  GtkWidget *input1;
  GtkWidget *fenetre_supprimer;
  fenetre_supprimer=lookup_widget(objet,"fenetre_supprimer");
  input1=lookup_widget(objet,"entry_agent_id");
  strcpy(ids,gtk_entry_get_text(GTK_ENTRY(input1)));
  supprimer_agent(ids);

  
}


void
on_button_back_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_supprimer, *fenetre_afficher;
GtkWidget *treeview1;
fenetre_afficher=lookup_widget(objet,"fenetre_afficher");
gtk_widget_destroy(fenetre_supprimer);
fenetre_afficher=create_fenetre_afficher();
gtk_widget_show(fenetre_afficher);
treeview1=lookup_widget(fenetre_afficher,"treeview1");
afficher_agent(treeview1);
}



void
on_backm_clicked                       (GtkWidget       *button,
                                        gpointer         user_data)
{

}



void
on_back_modif_clicked                  (GtkWidget       *button,
                                        gpointer         user_data)
{

}


void
on_valider_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{ GtkWidget *g,*b,*c, *e ,*d, *l1, *l ,*List_View ;
   

	Agent a ;	
	supprimer_agent(agent_selectionner.id);
	g=lookup_widget(objet,"entry_id_m");
	b=lookup_widget(objet,"entry_password_m");
	c=lookup_widget(objet,"entry_name_m");
	e=lookup_widget(objet,"entry_adress_m");
	d=lookup_widget(objet,"entry_phone_m");
	strcpy(agent_selectionner.id,gtk_entry_get_text(GTK_ENTRY(g)));
	strcpy(agent_selectionner.password,gtk_entry_get_text(GTK_ENTRY(b)));
        strcpy(agent_selectionner.name,gtk_entry_get_text(GTK_ENTRY(c)));
	strcpy(agent_selectionner.adress,gtk_entry_get_text(GTK_ENTRY(e)));
	strcpy(agent_selectionner.phone,gtk_entry_get_text(GTK_ENTRY(d)));
 
        ajouter_agent(agent_selectionner);
	l=create_fenetre_afficher();

	l1=lookup_widget(objet,"fenetre_modifier");
	gtk_widget_destroy(l1);

	List_View=lookup_widget(l,"treeview1");
	afficher_agent(List_View);
	gtk_widget_show (l);


}


void
on_treeview1_row_activated             (GtkTreeView     *treeview1,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
gchar *str_data;
GtkListStore *list_store;
list_store=gtk_tree_view_get_model(treeview1);
GtkTreeIter   iter;
  if (gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store), &iter, path))//
  { 
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 0, &str_data, -1);
  }

strcpy(agent_selectionner.id,str_data);
FILE *f ;
f=fopen("agent.txt","r");
Agent a ;
while (fscanf(f,"%s %s %s %s %s \n",a.id,a.password,a.name,a.adress,a.phone)!=EOF)
{
fscanf(f,"%s %s %s %s %s \n",a.id,a.password,a.name,a.adress,a.phone) ;
if (strcmp(agent_selectionner.id,a.id)==0) 
	agent_selectionner=a;

}



fclose(f);
}


