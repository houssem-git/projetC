#include <gtk/gtk.h>


void
on_button_show_clicked                 (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_home_clicked                 (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_add_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_retour_clicked               (GtkWidget       *button,
                                        gpointer         user_data);

void
on_manage_agent_account_clicked        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_show_client_list_clicked            (GtkWidget       *button,
                                        gpointer         user_data);

void
on_deleteagent_clicked                 (GtkWidget       *button,
                                        gpointer         user_data);

void
on_modifyagent_clicked                 (GtkWidget       *button,
                                        gpointer         user_data);

void
on_delete_id_clicked                   (GtkWidget      *button,
                                        gpointer         user_data);

void
on_button_back_clicked                 (GtkWidget       *button,
                                        gpointer         user_data);


void
on_backm_clicked                       (GtkWidget       *button,
                                        gpointer         user_data);



void
on_back_modif_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_valider_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);
