#include <gtk/gtk.h>
typedef struct 
{
char dropinplane[20];
char dropoffplane[20];
char from[20];
char to[20];
char nameplane[20];
char nbplace[20];
}plane;

void ajouter_plane(plane p);
void afficher_plane(GtkWidget *liste);
