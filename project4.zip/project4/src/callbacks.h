#include <gtk/gtk.h>


void
on_transportation_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_plane_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_consultplane_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_addplane_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_returnfenetreajout_clicked          (GtkWidget       *objet,
                                        gpointer         user_data);
