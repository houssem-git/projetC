#include <stdio.h>
#include <string.h>
#include "fplane.h"
#include <gtk/gtk.h>
 enum
{
	 DROPINPLANE,
	 DROPOFFPLANE,
	 FROM,
	 TO,
	 NAMEPLANE,
	 NBPLACE,
	 COLUMNS
 };
 //ajoutplane
void ajouter_plane(plane p)
 
{  	 
	 int jf1,mf1,af1,jt1,mt1,at1;
	 GtkWidget *input1 ,*input2,*input3,*input4,*input5,*input6;
  input1= lookup_widget(objet_graphique, "dayfrom") ;
  input2= lookup_widget(objet_graphique, "monthfrom") ;
  input3= lookup_widget(objet_graphique, "yearfrom") ;
  input4= lookup_widget(objet_graphique, "dayto") ;
  input5= lookup_widget(objet_graphique, "monthto") ;
  input6= lookup_widget(objet_graphique, "yearto") ;
    
  jf1=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input1));
  mf1=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input2));
  af1=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input3));
  jt1=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input4));
  mt2=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input5));
  at2=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input6));


  sprintf (from,"%d /%d /%d",jf1,mf1,af1);
  sprintf (to,"%d /%d /%d",jt1,mt1,at1);	 
	 FILE *f;
	 f=fopen("fplane.txt","a+");
	 if (f!=NULL)
	 {
		 fprintf(f,"%s %s %s %s %s %s\n",p.dropinplane,p.dropoffplane,p.from,p.to,p.nameplane,p.nbplace);
		 fclose(f);
	 }
 }
 
 //afficherplane
 void afficher_plane(GtkWidget *liste)
 {
	 GtkCellRenderer *renderer ;
	 GtkTreeViewColumn *column;
	 GtkTreeIter iter;
	 GtkListStore *store;
	 char dropinplane[20];
     	 char dropoffplane[20];
     	 char from[20];
     	 char to[20];
     	 char nameplane[20];
	 char nbplace[20];
	 store=NULL;
	 FILE *f;
	 store=gtk_tree_view_get_model(liste);
	 if (store==NULL)
	 {
		 renderer= gtk_cell_renderer_text_new();
		 column=gtk_tree_view_column_new_with_attributes("dropinplane", renderer,"text", DROPINPLANE,NULL);
		 gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
		 renderer=gtk_cell_renderer_text_new();
		 column= gtk_tree_view_column_new_with_attributes("dropoffplane", renderer,"text", DROPOFFPLANE,NULL);
		 gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
		 renderer=gtk_cell_renderer_text_new();
		 column= gtk_tree_view_column_new_with_attributes("from", renderer,"text", FROM,NULL);
		 gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
		 renderer=gtk_cell_renderer_text_new();
		 column= gtk_tree_view_column_new_with_attributes("to", renderer,"text", TO,NULL);
		 gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
		 renderer=gtk_cell_renderer_text_new();
		 column= gtk_tree_view_column_new_with_attributes("nameplane", renderer,"text", NAMEPLANE,NULL);
		 gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
		 renderer=gtk_cell_renderer_text_new();
                 column= gtk_tree_view_column_new_with_attributes("nbplace", renderer,"text", NBPLACE,NULL);
                 gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

		 store =gtk_list_store_new(COLUMNS,G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING);
		 f=fopen("fplane.txt", "r");
		 if (f==NULL)
		 {
			 return;
		 }
		 else 
		 { f=fopen("fplane.txt","a+");
				while (fscanf(f,"%s %s %s %s %s %s\n",dropinplane,dropoffplane,from,to,nameplane,nbplace)!=EOF)
				{
					gtk_list_store_append(store,&iter);
					gtk_list_store_set(store,&iter,DROPINPLANE,dropinplane,DROPOFFPLANE,dropoffplane,FROM,from,TO,to,NAMEPLANE,nameplane,NBPLACE,nbplace);
				}
				fclose(f);
				gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
				gtk_object_unref(store);
		 }
	 }
}
