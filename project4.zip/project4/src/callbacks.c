#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fplane.h"


void
on_transportation_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *homeagent, *fenetretransport;
homeagent=lookup_widget(objet,"homeagent");
gtk_widget_destroy(homeagent);
fenetretransport=create_fenetretransport();
gtk_widget_show(fenetretransport);

}


void
on_plane_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetreajoutplane, *fenetretransport;
fenetretransport=lookup_widget(objet,"fenetretransport");
gtk_widget_destroy(fenetretransport);
fenetreajoutplane=create_fenetreajoutplane();
gtk_widget_show(fenetreajoutplane);

}


void
on_consultplane_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetreajoutplane;
GtkWidget *fenetreafficherplane;
GtkWidget *treeview1;
fenetreajoutplane=lookup_widget(objet,"fenetreajoutplane");
gtk_widget_destroy(fenetreajoutplane);
fenetreafficherplane=lookup_widget(objet,"fenetreafficherplane");
fenetreafficherplane=create_fenetreafficherplane();
gtk_widget_show(fenetreafficherplane);
treeview1=lookup_widget(fenetreafficherplane,"treeview1");
afficher_plane(treeview1);

}


void
on_addplane_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
plane p;
GtkWidget *input1,*input2,*input3,*input4,*input5,*input6;
GtkWidget *fenetreajoutplane;
fenetreajoutplane=lookup_widget(objet,"fenetreajoutplane");
input1=lookup_widget(objet,"dropinplane");
input2=lookup_widget(objet,"dropoffplane");
input3=lookup_widget(objet,"from");
input4=lookup_widget(objet,"to");
input5=lookup_widget(objet,"nameplane");
input6=lookup_widget(objet,"nbplace");

strcpy(p.dropinplane,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(p.dropoffplane,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(p.from,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(p.to,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(p.nameplane,gtk_entry_get_text(GTK_ENTRY(input5)));
strcpy(p.nbplace,gtk_entry_get_text(GTK_ENTRY(input6)));

ajouter_plane(p);

}


void
on_returnfenetreajout_clicked          (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetreajoutplane, *fenetreafficherplane;
fenetreafficherplane=lookup_widget(objet,"fenetreafficherplane");
gtk_widget_destroy(fenetreafficherplane);
fenetreajoutplane=create_fenetreajoutplane();
gtk_widget_show(fenetreajoutplane);

}

