#include <gtk/gtk.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void
on_button1_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button2_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button3_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_manage_claim_clicked         (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_manage_agent_account_clicked (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_manage_provider_account_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_delete_provider_clicked      (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_add_provider_clicked         (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_modify_provider_clicked      (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_add_prv_clicked              (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_admin_home_clicked           (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_reset_prv_clicked            (GtkButton       *button,
                                        gpointer         user_data);


void
on_buttonaddagent_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonmodifyagent_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttondeleteagent_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonhomee_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_boutonresetajoutagent_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonhomeadmin_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_boutonvalideraddagent_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_delete_planeOffer_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_home_planeOffer_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_modify_planeOffer_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_add_planeOffer_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_hotel_prov_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_plane_prov_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button20_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_home_hotelOffer_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_edit_my_account_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_hotel_offers_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_plane_offers_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_back_to_agent_dash_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_back_to_agent_dash1_clicked         (GtkButton       *button,
                                        gpointer         user_data);
