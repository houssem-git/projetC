#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <gtk/gtk.h>
#include <string.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "callbacks.h"



void
on_button1_clicked                     (GtkWidget       *button,
                                        gpointer         user_data)
{
	
GtkWidget *inputlogin;
GtkWidget *inputpasswd;
GtkWidget *window2;
GtkWidget *window1;
GtkWidget *output;
GtkWidget * label15;
GtkWidget *window;

char log[20];
char pass[20];
char n[20];
char p[20];
char u[20];
int x=0;
window1=lookup_widget(button,"window1");

inputlogin=lookup_widget(button,"entry1");
inputpasswd=lookup_widget(button,"entry2");
strcpy(log,gtk_entry_get_text(GTK_ENTRY(inputlogin)));
strcpy(pass,gtk_entry_get_text(GTK_ENTRY(inputpasswd)));

FILE *f;
f=fopen("/home/jamiljoo/Projects/project1/src/utilisateurs.txt","r");

if(f !=NULL){
while(x==0&&fscanf(f,"%s %s \n",n,p)!=EOF)
{
	if(strcmp(log,n)==0 && strcmp(pass,p)==0)
		{
		window=create_window2();
		gtk_widget_hide(window1);
		gtk_widget_show_all(window);
		
		x=1;
		//output=lookup_widget(button,"label14");
		//gtk_label_set_text(GTK_LABEL(output),log);
		
		
	}


}
}
fclose(f);

if (x == 0)
{output=lookup_widget(button,"label5");
gtk_label_set_text(GTK_LABEL(output),"error");}


}


void
on_button2_clicked                     (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *window;
GtkWidget *window1;
window1=lookup_widget(button,"window1");
window=create_window4();
gtk_widget_hide(window1);
gtk_widget_show_all(window);
}


void
on_button3_clicked                     (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *window;
GtkWidget *window4;
window4=lookup_widget(button,"window4");
window=create_window5();
gtk_widget_hide(window4);
gtk_widget_show_all(window);

}


void
on_button_manage_claim_clicked         (GtkWidget       *button,
                                        gpointer         user_data)
{

}


void
on_button_manage_agent_account_clicked (GtkWidget       *button,
                                        gpointer         user_data)
{

}


void
on_button_manage_provider_account_clicked
                                        (GtkWidget       *button,
                                        gpointer         user_data)
{ 
GtkWidget *window;
GtkWidget *window2;
window2=lookup_widget(button,"window2");
window=create_window_manage_provider_account();
gtk_widget_hide(window2);
gtk_widget_show_all(window);

}


void
on_button_delete_provider_clicked      (GtkWidget       *button,
                                        gpointer         user_data)
{

}


void
on_button_add_provider_clicked         (GtkWidget       *button,
                                        gpointer         user_data)
{ GtkWidget *window;
GtkWidget *window_manage_provider_account;
window_manage_provider_account=lookup_widget(button,"window_manage_provider_account");
window=create_window_add_provider_account();
gtk_widget_hide(window_manage_provider_account);
gtk_widget_show_all(window);

}


void
on_button_modify_provider_clicked      (GtkWidget       *button,
                                        gpointer         user_data)
{

}


void
on_button_add_prv_clicked              (GtkWidget       *button,
                                        gpointer         user_data)
{

}


void
on_button_admin_home_clicked           (GtkWidget       *button,
                                        gpointer         user_data)
{

}


void
on_button_reset_prv_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{

}




void
on_buttonaddagent_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_buttonmodifyagent_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_buttondeleteagent_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_buttonhomee_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_boutonresetajoutagent_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_buttonhomeadmin_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_boutonvalideraddagent_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_delete_planeOffer_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_home_planeOffer_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_modify_planeOffer_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_add_planeOffer_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_hotel_prov_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_plane_prov_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button20_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_home_hotelOffer_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_edit_my_account_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_hotel_offers_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_plane_offers_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_back_to_agent_dash_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_back_to_agent_dash1_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{

}

